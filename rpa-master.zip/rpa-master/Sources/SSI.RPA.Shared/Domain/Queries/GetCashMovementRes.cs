﻿using MediatR;
using SSI.RPA.Shared;
using SSI.RPA.Shared.Dtos;
using System.Collections.Generic;

namespace SSI.RPA.Shared.Domain.Queries
{
    public class GetCashMovementRes
    {
        public string ReturnCode { get; set; }
        public string ErrCode { get; set; }
        public string ErrDesc { get; set; }
        public List<PRD_DVCK_CAS_BankCashReconciliationDto> TransList { get; set; }
    }

    public class GetCashMovementLogRes    {
        public string ReturnCode { get; set; }
        public string ErrCode { get; set; }
        public string ErrDesc { get; set; }
        public List<PRD_DVCK_CAS_BankCashReconciliationLogDto> TransList { get; set; }
    }
}
