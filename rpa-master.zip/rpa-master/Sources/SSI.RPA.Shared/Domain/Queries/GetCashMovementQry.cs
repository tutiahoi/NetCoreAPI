﻿using MediatR;
using SSI.RPA.Shared;
using SSI.RPA.Shared.Dtos;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SSI.RPA.Shared.Domain.Queries
{
    public class GetCashMovementQry : IRequest<GetCashMovementRes>
    {
        public string ReportType { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string Core { get; set; }
        public string BankAccountID { get; set; }                        
    }
}
