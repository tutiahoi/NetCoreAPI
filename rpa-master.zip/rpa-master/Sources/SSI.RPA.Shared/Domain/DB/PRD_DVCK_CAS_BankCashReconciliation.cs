using SSI.RPA.Shared.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace SSI.RPA.Shared.Domain.DB
{
    public partial class PRD_DVCK_CAS_BankCashReconciliation
    {
        public string Nguon { get; set; }
        public string LoaiDoiSoat { get; set; }
        public DateTime? ValueDate { get; set; }
        public string OrigTranID { get; set; }
        public string TransactionID { get; set; }
        public string TransName { get; set; }
        public string BankAccountID { get; set; }
        public string BankAccountName { get; set; }

        public string ToBankName { get; set; }
        public string ToBankBranch { get; set; }
        public string ToBankAccountNumber { get; set; }
        public string ToBankAccountName { get; set; }

        public string AccountID { get; set; }
        public string AccountName { get; set; }
        public decimal? Amount { get; set; }
        public string Remark { get; set; }
        public string TxnStatusCode { get; set; }
        public string TxnStatus { get; set; }

        public string CreatedBy { get; set; }
        public string UserTeamID { get; set; }

        public string LogicalBranchID { get; set; }
        public string MovementType { get; set; }

        public string TransactionReference { get; set; }
        public string RegistrationType { get; set; }        
    }
}
