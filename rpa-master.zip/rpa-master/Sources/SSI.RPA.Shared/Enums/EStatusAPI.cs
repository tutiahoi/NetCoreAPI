﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace SSI.RPA.Shared.Enums
{
    public enum EStatusAPI
    {
        [Description("Thành công")]
        Success = 0,

        [Description("Thất bại")]
        Fail = 1,

        #region Error validate FO
        [Description("Không tồn tại dữ liệu")]
        NotExisted = 100,

        [Description("Dữ liệu đầu vào không chính xác")]
        InvalidInput = 200,

        [Description("Có ký tự lạ, tiếng việt có dấu")]
        WrongCharacter = 1005,
        #endregion

        #region OTP
        [Description("Số lần gửi OTP vượt giới hạn")]
        LimitOTPSend = 201,

        [Description("Số lần xác thực OTP vượt giới hạn")]
        LimitOTPVerify = 202,

        [Description("Giải mã dữ liệu không thành công")]
        FailDecryptData = 203,

        [Description("Loại OTP không chính xác")]
        InvalidOTPType = 204,

        [Description("Email/Mobile OTP không chính xác")]
        InvalidOTPObject = 205,

        [Description("Mã OTP không chính xác")]
        OTPNotRight = 206,

        [Description("Mã OTP không tồn tại")]
        OTPNotExits = 207,

        [Description("Khách hàng chưa kích hoạt OTP")]
        OTPNotActive = 208,

        [Description("Yêu cầu khách hàng nhập OTP")]
        OTPSubmit = 209,

        #endregion

        #region Lỗi tại FO
        [Description("Tài khoản đã đóng")]
        BankAccountClosed = 210,

        [Description("Tài khoản không được phép giao dịch")]
        BankAccountNotAllowed = 211,

        [Description("Tài khoản không đủ số dư")]
        NotEnoughBalance = 212,

        [Description("Vượt hạn mức giao dịch trong ngày")]
        OverDailyLimit = 213,

        [Description("Không tạo được giao dịch thanh toán")]
        CreateTransFail = 221,

        [Description("BankID không tồn tại")]
        BankNotExist = 117,

        #endregion

        #region Lỗi bên bank
        [Description("Giao dịch bị lỗi (Timeout, lỗi hệ thống)")]
        BankTimeOut = 223,

        [Description("Hệ thống đang bị gián đoạn,đề nghị QK thực hiện lại giao dịch sau")]
        BankSystemFail = 224,

        [Description("Lỗi chữ ký số")]
        BankSignFail = 225,

        [Description("Validation tại bank thất bại")]
        BankValidationFail = 226,

        [Description("Tài khoản ngân hàng không hợp lệ")]
        BankAcctValidFail = 227,

        [Description("Số điện thoại không hợp lệ")]
        PhoneNumValidFail = 228,

        [Description("Mã hóa Message không chính xác")]
        SecureMessageFail = 229,

        [Description("Quá số lần liên kết trong ngày")]
        LinkAcctMaxDaily = 230,

        [Description("Số tiền không hợp lệ")]
        AmountValidFail = 231,

        [Description("Thông tin khách hàng không chính xác")]
        CustomerInfoFail = 232,

        [Description("Số tiền giao dịch vượt quá hạn mức tối đa đối với mỗi giao dịch")]
        OverTransactionLimit = 233,

        [Description("Số tài khoản không tồn tại")]
        AccountNotExist = 234,

        [Description("Thông tin Quý khách chưa đăng ký tài khoản tại ngân hàng")]
        CustomerInfoNotExist = 235,

        [Description("Tài khoản không đủ số dư tổi thiểu")]
        OverAccountMinBal = 236,

        [Description("Giao dịch đang được xử lý tại ngân hàng")]
        TransactionPending = 298,

        [Description("Giao dịch bị hủy")]
        TransactionCanceled = 299,
        #endregion

        [Description("Mã xác thực không tồn tại")]
        TokenConfirmNotExist = 300,
        [Description("Mã đã xác thực")]
        TokenConfirmed = 301,
        [Description("Mã xác thực hết hạn")]
        TokenConfirmExpired = 302,
        [Description("Hệ thống xảy ra lỗi trong quá trình xác thực OTP tại ngân hàng")]
        VerifyOTPFailed = 303,
        [Description("Hệ thống xảy ra lỗi trong quá trình xác thực OTP tại ngân hàng hoặc khách hàng bị khóa OTP tạm thời do nhập sai OTP nhiều lần liên tiếp")]
        LockOTP = 304,
       
        [Description("Không có quyền truy cập")]
        Forbidden = 403,

        [Description("Lỗi hệ thống (Exception)")]
        Exception = 1000,

        [Description("Timeout")]
        TimeOut = 1001,

        #region Mapping token status
        [Description("Liên kết đã tồn tại")]
        TokenExist = 119,
        [Description("Liên kết không tồn tại")]
        TokenNotFound = 122,
        [Description("Liên kết đã hết hạn")]
        TokenExpired = 120,
        [Description("Liên kết đã bị hủy")]
        TokenDeactive = 121,

        #endregion

        #region Deposit cash

        [Description("Không có kết nối với bank")]
        BankNotConnected = 124,

        [Description("Trùng RefNumber")]
        RefNumberExits = 240,

        [Description("Trùng transaction ID")]
        TransExits = 241,

        [Description("Không tồn tại transaction ID")]
        TransNotExits = 242,

        #endregion

        #region Data verify
        [Description("Đã tồn tại bản ghi")]
        DataExists = 243,
        #endregion

        [Description("Quý khách vui lòng thực hiện kích hoạt lại dich vụ SmartBanking tại Quầy giao dịch của ngân hàng")]
        ContactBankSupport = 998,

        [Description("Lỗi khác")]
        OtherError = 999
    }
}
