﻿using System.ComponentModel;

namespace SSI.RPA.Shared.Enums
{
    public enum EYesNo
    {
        [Description("Không")]
        No = 0,

        [Description("Có")]
        Yes = 1
    }
}
