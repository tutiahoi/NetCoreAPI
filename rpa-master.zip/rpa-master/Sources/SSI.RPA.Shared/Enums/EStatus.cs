﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace SSI.RPA.Shared.Enums
{
    public enum EStatus
    {
        [Description("Hoạt động")]
        Active = 1,

        [Description("Không hoạt động")]
        InActive = 0
    }
}
