﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace SSI.RPA.Shared.Enums
{
    public enum EReturnCode
    {
        [Description("Thành công")]
        SUCCESS = 0,
        [Description("Thất bại")]
        FAIL = 1,
        [Description("Chờ xử lý")]
        PENDING = 2
    }
}
