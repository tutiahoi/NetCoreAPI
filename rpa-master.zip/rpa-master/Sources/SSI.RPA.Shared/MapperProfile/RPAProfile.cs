﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AutoMapper;
using SSI.RPA.Common.Utilities;
using SSI.RPA.Shared.Domain;
using SSI.RPA.Shared.Domain.DB;
using SSI.RPA.Shared.Domain.Queries;
using SSI.RPA.Shared.Dtos;

namespace SSI.RPA.Shared.MapperProfile
{
    public class RPAProfile : Profile
    {
        public RPAProfile()
        {
            CreateMap<string, string>().ConvertUsing(str => (str ?? "").Trim());            

            CreateMap<PRD_DVCK_CAS_BankCashReconciliation, PRD_DVCK_CAS_BankCashReconciliationDto>()
               .ForMember(des => des.Core, m => m.MapFrom(src => src.Nguon))
               .ForMember(des => des.TransType, m => m.MapFrom(src => src.LoaiDoiSoat))
               .ForMember(des => des.TransDate, m => m.MapFrom(src => src.ValueDate))
               .ForMember(des => des.Status, m => m.MapFrom(src => src.TxnStatusCode))
               .ForMember(des => des.StatusName, m => m.MapFrom(src => src.TxnStatus));

            CreateMap<GetCashMovementRes, GetCashMovementLogRes>();
            CreateMap<PRD_DVCK_CAS_BankCashReconciliationDto, PRD_DVCK_CAS_BankCashReconciliationLogDto>();
            
        }
    }
}