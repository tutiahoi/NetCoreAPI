﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Primitives;
using Newtonsoft.Json;
using SSI.RPA.Common;
using SSI.RPA.Shared.Dtos;
using SSI.RPA.Shared.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace SSI.RPA.Shared.CustomAuthorized
{
    public class KeyAuthenFilter : IAuthorizationFilter
    {
        private readonly ILogger<KeyAuthenFilter> _logger;

        private readonly IConfiguration Configuration;

        public static string ApiKeyHeaderName = "ApiKey";
        public static string ClientIdHeaderName = "ClientId";

        public KeyAuthenFilter(ILogger<KeyAuthenFilter> logger, IConfiguration configuration)
        {
            _logger = logger;
            Configuration = configuration;

        }

        public void OnAuthorization(AuthorizationFilterContext context)
        {
            var request = context.HttpContext.Request;

            var hasApiKeyHeader = request.Headers.TryGetValue(ApiKeyHeaderName, out var apiKeyValue);
            if (hasApiKeyHeader)
            {
                //_logger.LogDebug("Found the header {ApiKeyHeader}. Starting API Key validation", ApiKeyHeaderName);
                if (apiKeyValue.Count != 0 && !string.IsNullOrWhiteSpace(apiKeyValue))
                {
                    if (request.Headers.TryGetValue(ClientIdHeaderName, out var clientIdValue) && clientIdValue.Count != 0 && !string.IsNullOrWhiteSpace(clientIdValue))
                    {
                        if (clientIdValue == Configuration.GetValue<string>("ClientId") && apiKeyValue == Configuration.GetValue<string>("ApiKey"))
                        {
                            //_logger.LogDebug("Client {ClientId} successfully logged in with key {ApiKey}", clientIdValue, apiKeyValue);

                            var apiKeyClaim = new Claim("apikey", apiKeyValue);
                            var subject = new Claim(ClaimTypes.Name, clientIdValue);
                            var principal = new ClaimsPrincipal(new ClaimsIdentity(new List<Claim> { apiKeyClaim, subject }, "ApiKey"));
                            context.HttpContext.User = principal;

                            return;
                        }
                        //_logger.LogWarning("ClientId {ClientId} with ApiKey {ApiKey} is not authorized", clientIdValue, apiKeyValue);
                    }
                    else
                    {
                        _logger.LogWarning("{HeaderName} header not found or it was null or empty", ClientIdHeaderName);
                    }
                }
                else
                {
                    _logger.LogWarning("{HeaderName} header found, but api key was null or empty", ApiKeyHeaderName);
                }
            }
            else
            {
                _logger.LogWarning("No ApiKey header found.");
            }

            context.Result = new UnauthorizedResult();
        }
    }
}
