﻿using Microsoft.Extensions.Logging;
using System;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace SSI.RPA.Shared.Security
{
    public class Signature
    {
        public string szP12File { get; set; }
        public string szPasswordP12 { get; set; }
        public string cerFile { get; set; }
        private readonly ILogger<Signature> _logger;
        public Signature(ILogger<Signature> logger)
        {
            _logger = logger;
        }

        public string SignDataSHA1(string _data, ref bool _checkSuccess)
        {
            try
            {
                var cert = new X509Certificate2(szP12File, szPasswordP12);
                var rsa1 = (RSACryptoServiceProvider)cert.PrivateKey;
                var encoding = new UTF8Encoding();
                byte[] hash = encoding.GetBytes(_data);
                byte[] data = rsa1.SignData(hash, CryptoConfig.MapNameToOID("SHA1"));
                string kq = Convert.ToBase64String(data);

                _checkSuccess = true;
                return kq;
            }
            catch (Exception ex)
            {
                _logger.LogError(this.szP12File);
                _logger.LogError(this.szPasswordP12);
                _logger.LogError(ex.ToString());
                _checkSuccess = false;
                return "";
            }
        }

        public string SignDataSHA256_TCB(string data, ref bool _check)
        {
            byte[] signature = null;
            var encoding = new UTF8Encoding();
            byte[] bytes = encoding.GetBytes(data);
            using (SHA256 sha256Hash = SHA256.Create())
            {
                // ComputeHash - returns byte array  
                byte[] hash = sha256Hash.ComputeHash(bytes);
                try
                {
                    X509Certificate2 rsaPrivate = new X509Certificate2(szP12File, szPasswordP12, X509KeyStorageFlags.Exportable);
                    if (rsaPrivate != null && rsaPrivate.HasPrivateKey)
                    {
                        RSACryptoServiceProvider key = new RSACryptoServiceProvider();
                        key.FromXmlString(rsaPrivate.PrivateKey.ToXmlString(true));

                        signature = key.SignData(hash, CryptoConfig.MapNameToOID("SHA256"));
                        _check = true;
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex.ToString());
                    _check = false;
                }
                return Convert.ToBase64String(signature);
            }
        }

        public string SignDataSHA256_TCB_Correct(string data, ref bool _check)
        {
            byte[] signature = null;
            var encoding = new UTF8Encoding();
            byte[] bytes = encoding.GetBytes(data);
            using (SHA256 sha256Hash = SHA256.Create())
            {
                // ComputeHash - returns byte array  
                try
                {
                    X509Certificate2 rsaPrivate = new X509Certificate2(szP12File, szPasswordP12, X509KeyStorageFlags.Exportable);
                    if (rsaPrivate != null && rsaPrivate.HasPrivateKey)
                    {
                        RSACryptoServiceProvider key = new RSACryptoServiceProvider();
                        key.FromXmlString(rsaPrivate.PrivateKey.ToXmlString(true));

                        signature = key.SignData(bytes, CryptoConfig.MapNameToOID("SHA256"));
                        _check = true;
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex.ToString());
                    _check = false;
                }
                return Convert.ToBase64String(signature);
            }
        }

        public bool VerifyDataSHA256_TCB(string signature, string data, bool userRSACng = false)
        {
            try
            {
                X509Certificate2 certPublic = new X509Certificate2(cerFile);
                if (userRSACng)
                {
                    RSACng csp = (RSACng)certPublic.PublicKey.Key;
                    SHA256Managed sha256 = new SHA256Managed();
                    var encoding = new UTF8Encoding();
                    byte[] cdata = encoding.GetBytes(data);

                    byte[] csignature = Convert.FromBase64String(signature);
                    byte[] hash = sha256.ComputeHash(cdata);

                    return csp.VerifyData(hash, csignature, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
                }
                else
                {
                    RSACryptoServiceProvider csp = (RSACryptoServiceProvider)certPublic.PublicKey.Key;
                    SHA256Managed sha256 = new SHA256Managed();
                    var encoding = new UTF8Encoding();
                    byte[] cdata = encoding.GetBytes(data);

                    byte[] csignature = Convert.FromBase64String(signature);
                    byte[] hash = sha256.ComputeHash(cdata);

                    return csp.VerifyData(hash, CryptoConfig.MapNameToOID("SHA256"), csignature);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.ToString());
                return false;
            }
        }

        public string EncryptAESRSA_TCB(string data, ref bool _check, bool userRSACng = false)
        {
            var encoding = new UTF8Encoding();
            byte[] toEncryptAES = encoding.GetBytes(data);

            byte[] encryptedAES = null;
            byte[] encryptedRSA = null;

            try
            {
                using (RijndaelManaged AES = new RijndaelManaged())
                {
                    AES.KeySize = 256;
                    AES.BlockSize = 128;
                    AES.Mode = CipherMode.CBC;
                    AES.Padding = PaddingMode.PKCS7;
                    AES.GenerateIV();
                    AES.GenerateKey();

                    X509Certificate2 certPublic = new X509Certificate2(cerFile);
                    if (userRSACng)
                    {
                        RSACng csp = (RSACng)certPublic.PublicKey.Key;
                        encryptedRSA = csp.Encrypt(AES.Key,RSAEncryptionPadding.Pkcs1);
                    }
                    else
                    {
                        RSACryptoServiceProvider csp = (RSACryptoServiceProvider)certPublic.PublicKey.Key;
                        encryptedRSA = csp.Encrypt(AES.Key, false);
                    }

                    var cxform = AES.CreateEncryptor();
                    var encryptedBlob = cxform.TransformFinalBlock(toEncryptAES, 0, toEncryptAES.Length);

                    encryptedAES = new byte[AES.IV.Length + encryptedBlob.Length];
                    System.Buffer.BlockCopy(AES.IV, 0, encryptedAES, 0, AES.IV.Length);
                    System.Buffer.BlockCopy(encryptedBlob, 0, encryptedAES, AES.IV.Length, encryptedBlob.Length);

                }

                byte[] resultByte = new byte[encryptedRSA.Length + encryptedAES.Length];
                System.Buffer.BlockCopy(encryptedRSA, 0, resultByte, 0, encryptedRSA.Length);
                System.Buffer.BlockCopy(encryptedAES, 0, resultByte, encryptedRSA.Length, encryptedAES.Length);

                var result = Convert.ToBase64String(resultByte);
                _check = true;
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.ToString());
                _check = false;
                return string.Empty;
            }
        }
    }
}
