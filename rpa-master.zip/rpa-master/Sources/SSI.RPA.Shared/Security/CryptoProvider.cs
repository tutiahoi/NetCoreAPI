﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Xml;

namespace SSI.RPA.Shared.Security
{
    public class CryptoProvider
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<CryptoProvider> _logger;

        public CryptoProvider(IConfiguration configuration, ILogger<CryptoProvider> logger)
        {
            _configuration = configuration;
            _logger = logger;
        }

        public string Encryption(string strText)
        {
            string publicKeyPath = _configuration.GetValue<string>("Public_Key_RSA_Path");
            string strPublicKeyXml = ReadfromFile(publicKeyPath);
            var encryptData = Encoding.UTF8.GetBytes(strText);

            using (var rsa = new RSACryptoServiceProvider(1024))
            {
                try
                {
                    // client encrypting data with public key issued by server                    
                    rsa.FromXmlString(strPublicKeyXml);

                    var encryptedData = rsa.Encrypt(encryptData,RSAEncryptionPadding.Pkcs1);

                    var base64Encrypted = Convert.ToBase64String(encryptedData);

                    return base64Encrypted;
                }
                catch(Exception ex)
                {
                    _logger.LogError(ex.ToString());
                    return string.Empty;
                }
                finally
                {
                    rsa.PersistKeyInCsp = false;
                }
            }
        }

        public string Decryption(string strText)
        {
            string privateKeyPath = _configuration.GetValue<string>("Private_Key_RSA_Path");
            string strPrivateKeyXml = ReadfromFile(privateKeyPath);

            using (var rsa = new RSACryptoServiceProvider(1024))
            {
                try
                {
                    var base64Encrypted = strText;

                    // server decrypting data with private key                    
                    rsa.FromXmlString(strPrivateKeyXml);

                    var resultBytes = Convert.FromBase64String(base64Encrypted);
                    var decryptedBytes = rsa.Decrypt(resultBytes, RSAEncryptionPadding.Pkcs1);
                    var decryptedData = Encoding.UTF8.GetString(decryptedBytes);
                    return decryptedData.ToString();
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex.ToString());
                    return string.Empty;
                }
                finally
                {
                    rsa.PersistKeyInCsp = false;
                }
            }
        }

        private static string ReadfromFile(string filePath)
        {
            using (XmlReader xr = XmlReader.Create(filePath, new XmlReaderSettings() { IgnoreWhitespace = true }))
            {
                using (StringWriter sw = new StringWriter())
                {
                    using (XmlWriter xw = XmlWriter.Create(sw))
                    {
                        xw.WriteNode(xr, false);
                    }
                    return sw.ToString();
                }
            }
        }

        public T Decrypt<T>(string data)
        {
            var plainData = Decryption(data);
            if (plainData == string.Empty)
                return default(T);
            return JsonConvert.DeserializeObject<T>(plainData);
        }
    }
}
