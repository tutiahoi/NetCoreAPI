﻿using SSI.RPA.Shared.Dtos;
using SSI.RPA.Shared.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SSI.RPA.Shared
{
    public class BaseRes<T> : BaseRes
    {
        public T Data { get; set; }
        public BaseRes() { }
        public BaseRes(EStatusAPI status, string errorKey, string errorMessage) : base(status, errorKey, errorMessage){}
        public BaseRes(EStatusAPI status, Dictionary<string, List<string>> errors) : base(status, errors) { }
    }

    

    public class BaseRes
    {
        public EStatusAPI Status { get; set; }

        public Dictionary<string, List<string>> Errors { get; set; }

        public BaseRes() { }

        public BaseRes(EStatusAPI status, string errorKey, string errorMessage)
        {
            Status = status;
            Errors = new Dictionary<string, List<string>>()
            {
                {errorKey,new List<string>{errorMessage} }
            };
        }

        public BaseRes(EStatusAPI status, Dictionary<string, List<string>> errors)
        {
            Status = status;
            Errors = errors;
        }   
    }
}
