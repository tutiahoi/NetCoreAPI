using System;
using System.Collections.Generic;
using System.Text;

namespace SSI.RPA.Shared.Dtos
{
    public class PRD_DVCK_CAS_BankCashReconciliationDto
    {
        public string Core { get; set; }
        public string TransType { get; set; }
        public DateTime? TransDate { get; set; }
        public string OrigTranID { get; set; }
        public string TransactionID { get; set; }
        public string TransName { get; set; }
        public string BankAccountID { get; set; }
        public string BankAccountName { get; set; }
        public string ToBankName { get; set; }
        public string ToBankBranch { get; set; }
        public string ToBankAccountNumber { get; set; }
        public string ToBankAccountName { get; set; }
        public string AccountID { get; set; }
        public string AccountName { get; set; }
        public decimal? Amount { get; set; }
        public string Remark { get; set; }
        public string Status { get; set; }
        public string StatusName { get; set; }
        public string CreatedBy { get; set; }
        public string UserTeamID { get; set; }
        public string LogicalBranchID { get; set; }
        public string MovementType { get; set; }
        
        public string TransactionReference { get; set; }
        public string RegistrationType { get; set; }
    }

    public class PRD_DVCK_CAS_BankCashReconciliationLogDto
    {
        //public string Core { get; set; }
        public string TransType { get; set; }
        //public DateTime? TransDate { get; set; }
        public string OrigTranID { get; set; }
        //public string TransactionID { get; set; }
        //public string TransName { get; set; }
        //public string BankAccountID { get; set; }
        //public string BankAccountName { get; set; }
        //public string ToBankName { get; set; }
        //public string ToBankBranch { get; set; }
        //public string ToBankAccountNumber { get; set; }
        //public string ToBankAccountName { get; set; }
        public string AccountID { get; set; }        
        //public decimal? Amount { get; set; }        
        //public string Status { get; set; }
        //public string StatusName { get; set; }
        //public string CreatedBy { get; set; }
        //public string UserTeamID { get; set; }
        //public string LogicalBranchID { get; set; }
        //public string MovementType { get; set; }
        //public string TransactionReference { get; set; }
        //public string RegistrationType { get; set; }
    }
}
