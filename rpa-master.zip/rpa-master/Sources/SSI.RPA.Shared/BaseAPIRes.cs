﻿using SSI.RPA.Shared.Enums;

namespace SSI.RPA.Shared
{
    public class BaseAPIRes<T> : BaseAPIRes
    {
        public T Data { get; set; }

    }

    public class BaseAPIRes
    {
        public EStatusAPI Status { get; set; }

        public string ErrorMessage { get; set; }

        public BaseAPIRes()
        {
        }

        public BaseAPIRes(EStatusAPI _status, string errMessage)
        {
            Status = _status;
            ErrorMessage = errMessage;
        }
    }
}
