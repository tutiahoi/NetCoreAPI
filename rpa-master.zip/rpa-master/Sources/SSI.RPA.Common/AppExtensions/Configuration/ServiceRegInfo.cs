﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SSI.RPA.Common
{
    public class ServiceRegInfo
    {
        public string ServiceRegName { get; set; }
        public string ServiceRegID { get; set; }
        public string ServiceRegIP { get; set; }
        public int ServiceRegPort { get; set; }
        public string[] ServiceRegTags { get; set; }

        public bool ServiceHealthCheckTCP { get; set; }
        public bool ServiceHealthCheckHTTP { get; set; }
    }
}
