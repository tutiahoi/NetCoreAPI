﻿using Microsoft.Extensions.Logging;
using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Threading.Tasks;

namespace SSI.RPA.Common.SMS
{
    public class SMSService : ISMSService
    {
        private readonly ILogger<SMSService> _logger;
        private readonly MySqlDatabase _dbSMS;

        public SMSService(MySqlDatabase dbSMS, ILogger<SMSService> logger)
        {
            _logger = logger;
            _dbSMS = dbSMS;
        }

        public async Task SendSMS(string mobilephone, string message, int messageType, string stamp)
        {
            try
            {
                await _dbSMS.Connection.OpenAsync();
                var cmd = _dbSMS.Connection.CreateCommand();
                cmd.CommandText = "INSERT INTO tblqueue(mobilephone, message, messagetype, stamp) VALUES(@mobilephone,@message,@messageType,@stamp)";
                cmd.Parameters.Add(new MySqlParameter
                {
                    ParameterName = "@mobilephone",
                    DbType = DbType.String,
                    Value = mobilephone,

                });

                cmd.Parameters.Add(new MySqlParameter
                {
                    ParameterName = "@message",
                    DbType = DbType.String,
                    Value = message,

                });

                cmd.Parameters.Add(new MySqlParameter
                {
                    ParameterName = "@messageType",
                    DbType = DbType.Int32,
                    Value = messageType,

                });

                cmd.Parameters.Add(new MySqlParameter
                {
                    ParameterName = "@stamp",
                    DbType = DbType.String,
                    Value = stamp,

                });
                await cmd.ExecuteNonQueryAsync();
                await cmd.DisposeAsync();
                await _dbSMS.Connection.CloseAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.ToString());
                await _dbSMS.Connection.CloseAsync();
            }
        }
    }
}
