﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SSI.RPA.Common.SMS
{
    public interface ISMSService
    {
        Task SendSMS(string mobilephone, string message, int messageType, string stamp);
    }
}
