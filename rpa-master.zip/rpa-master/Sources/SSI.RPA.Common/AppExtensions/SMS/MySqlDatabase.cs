﻿using MySql.Data.MySqlClient;
using System;
using System.Threading.Tasks;

namespace SSI.RPA.Common.SMS
{
    public class MySqlDatabase : IDisposable
    {
        public MySqlConnection Connection;

        public MySqlDatabase(string connectionString)
        {
            Connection = new MySqlConnection(connectionString);
        }

        public void Dispose()
        {
            Connection.Close();
        }
    }
}
