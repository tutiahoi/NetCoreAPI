﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using SSI.RPA.Common.SMS;

namespace SSI.RPA.Common.SMS
{
    public static class SMSInstaller
    {
        public static IServiceCollection AddSMSConfiguration(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddTransient<MySqlDatabase>(
                _ => new MySqlDatabase(configuration.GetConnectionString("SMSConnection")));            
            services.AddScoped<ISMSService, SMSService>();
            return services;
        }
    }
}
