using ICSharpCode.SharpZipLib.Zip;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Primitives;
using Newtonsoft.Json;
using System;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Text.RegularExpressions;

namespace SSI.RPA.Common
{
    public static class ObjectExtensions
    {
        public static byte[] CompressByte(this byte[] data)
        {
            MemoryStream output = new MemoryStream();
            using (DeflateStream dstream = new DeflateStream(output, CompressionLevel.Optimal))
            {
                dstream.Write(data, 0, data.Length);
            }
            return output.ToArray();
        }

        public static byte[] DecompressByte(this byte[] data)
        {
            MemoryStream input = new MemoryStream(data);
            MemoryStream output = new MemoryStream();
            using (DeflateStream dstream = new DeflateStream(input, CompressionMode.Decompress))
            {
                dstream.CopyTo(output);
            }
            return output.ToArray();
        }

        public static string PKZip(this string str)
        {
            try
            {
                byte[] byteArray = System.Text.Encoding.UTF8.GetBytes(str);

                MemoryStream outputStream = new MemoryStream();
                ZipOutputStream pkzipOutputStream = new ZipOutputStream(outputStream);

                ZipEntry entry = new ZipEntry("zipdata");
                entry.Size = byteArray.Length;


                pkzipOutputStream.PutNextEntry(entry);

                pkzipOutputStream.Write(byteArray, 0, byteArray.Length);
                pkzipOutputStream.Finish();

                byte[] zipByteArray = new byte[outputStream.Length];
                outputStream.Position = 0;
                outputStream.Read(zipByteArray, 0, (int)outputStream.Length);

                pkzipOutputStream.Close();

                return System.Convert.ToBase64String(zipByteArray).Replace("[\r\n]", "");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static string Unpkzip(this string zipedStr)
        {
            try
            {
                byte[] data = Convert.FromBase64String(zipedStr);
                MemoryStream input = new MemoryStream(data);

                ZipInputStream zip = new ZipInputStream(input);

                MemoryStream output = new MemoryStream();

                byte[] tempBuffer = new byte[1024];
                int numberOfBytesWritten;
                if (zip.GetNextEntry() != null)
                {
                    while ((numberOfBytesWritten = zip.Read(tempBuffer, 0, tempBuffer.Length)) > 0)
                    {
                        output.Write(tempBuffer, 0, numberOfBytesWritten);
                    }
                }
                zip.Close();
                output.Close();

                return System.Text.Encoding.UTF8.GetString(output.ToArray());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static string ToUnsign(this string str)
        {
            try
            {
                Regex regex = new Regex("\\p{IsCombiningDiacriticalMarks}+");
                string temp = str.Normalize(NormalizationForm.FormD);
                return regex.Replace(temp, String.Empty).Replace('\u0111', 'd').Replace('\u0110', 'D');
            }
            catch (Exception ex)
            {
                return str;
            }
        }

        public static bool IsContainInvalidCharacter(this string str)
        {
            try
            {

                string specialChar = "<>;,'\"@&%#/\\=";
                foreach (var c in specialChar)
                {
                    if (str.Contains(c)) return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public static string ToHexStringEncode(this string str, bool forceEncoding = false, bool hasEncodedPrefix = true)
        {
            bool hasSpecialCharacter = false;
            for (int i = 0; i < str.Length; i++)
            {
                if ((int)str[i] < 32 || (int)str[i] > 127 || "<>|~`@".Contains(str[i]))
                {
                    hasSpecialCharacter = true;
                }
            }

            if (hasSpecialCharacter || forceEncoding)
            {
                var sb = new StringBuilder();
                if (hasEncodedPrefix)
                    sb.Append("~");

                for (int i = 0; i < str.Length; i++)
                {
                    int value = Convert.ToInt32(str[i]);
                    var encodedCharacter = value.ToString("X2");
                    for (int j = 0; j < (4 - encodedCharacter.Length); j++)
                    {
                        sb.Append("0");
                    }
                    sb.Append(encodedCharacter);
                }

                return sb.ToString();
            }
            else
                return str;
        }

        /// <summary>
        ///     JSON Serialization
        /// </summary>
        public static string ToString<T>(this T t)
        {
            return JsonConvert.SerializeObject(t);
        }

        public static string ToJson(this object source)
        {
            if (source == null) return string.Empty;
            return JsonConvert.SerializeObject(source);
        }

        /// <summary>
        ///     JSON Deserialization
        /// </summary>
        public static T ToJson<T>(this string jsonString)
        {
            return JsonConvert.DeserializeObject<T>(jsonString);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="input"></param>
        /// <param name="length"></param>
        /// <returns></returns>
        public static string TruncateAtWord(this string input, int length)
        {
            if (input == null || input.Length < length)
                return input;
            int iNextSpace = input.LastIndexOf(" ", length, StringComparison.Ordinal);
            return string.Format("{0}�", input.Substring(0, (iNextSpace > 0) ? iNextSpace : length).Trim());
        }

        /// <summary>
        /// Function to get object from byte array
        /// </summary>
        /// <param name="byteArray">byte array to get object</param>
        /// <returns>object</returns>
        public static T To<T>(this byte[] byteArray)
        {
            if (byteArray == null)
                return default(T);

            try
            {
                // convert byte array to memory stream
                using (var memoryStream = new MemoryStream(byteArray))
                {
                    var binaryFormatter = new BinaryFormatter();

                    // set memory stream position to starting point
                    memoryStream.Position = 0;

                    // Deserializes a stream into an object graph and return as a object.
                    object obj = binaryFormatter.Deserialize(memoryStream);
                    return (T)obj;
                }
            }
            catch (Exception exception)
            {
            }
            // Error occured, return null
            return default(T);
        }

        /// <summary>
        /// Function to get byte array from a object
        /// </summary>
        /// <param name="_Object">object to get byte array</param>
        /// <returns>Byte Array</returns>
        public static byte[] ToByteArray(this object _Object)
        {
            try
            {
                // create new memory stream
                using (var memoryStream = new MemoryStream())
                {
                    var binaryFormatter = new BinaryFormatter();

                    // Serializes an object, or graph of connected objects, to the given stream.
                    binaryFormatter.Serialize(memoryStream, _Object);

                    // convert stream to byte array and return
                    return memoryStream.ToArray();
                }
            }
            catch (Exception exception)
            {

            }
            // Error occured, return null
            return null;
        }

        public static decimal ToDecimal(this object source)
        {
            if (source.IsStringNullOrEmpty()) return 0;

            decimal value;
            return decimal.TryParse(source.ToString(), out value) ? value : 0;
        }

        public static float ToFloat(this object source)
        {
            if (source.IsStringNullOrEmpty()) return 0;

            float value;
            return float.TryParse(source.ToString(), out value) ? value : 0;
        }

        public static int ToInt32(this object source)
        {
            if (source.IsStringNullOrEmpty()) return 0;

            int value;
            return int.TryParse(source.ToString(), out value) ? value : 0;
        }

        public static long ToInt64(this object source)
        {
            if (source.IsStringNullOrEmpty()) return 0;

            long value;
            return long.TryParse(source.ToString(), out value) ? value : 0;
        }

        public static byte ToByte(this object source)
        {
            if (source.IsStringNullOrEmpty()) return 0;

            byte value;
            return byte.TryParse(source.ToString(), out value) ? value : Convert.ToByte(0);
        }

        public static bool IsInteger(this object obj)
        {
            int outObj;
            return int.TryParse(obj.ToString(), out outObj);
        }

        public static bool IsLong(this object obj)
        {
            long outObj;
            return long.TryParse(obj.ToString(), out outObj);
        }

        public static bool IsIntegerNull(this object obj)
        {
            try
            {
                if (obj.IsStringNullOrEmpty()) return true;
                if (obj.IsInteger() && obj.ToString().Trim() == string.Empty) return true;
                if (obj.IsInteger() && obj.ToString().Trim() == "0") return true;
                if (obj.IsInteger() && obj.ToString().Trim() == "-1") return true;
                return false;
            }
            catch
            {
                return false;
            }
        }

        public static bool IsLongNull(this object obj)
        {
            try
            {
                if (obj.IsStringNullOrEmpty()) return true;
                if (obj.IsLong() && obj.ToString().Trim() == string.Empty) return true;
                if (obj.IsLong() && obj.ToString().Trim() == "0") return true;
                if (obj.IsLong() && obj.ToString().Trim() == "-1") return true;
                return false;
            }
            catch
            {
                return false;
            }
        }

        public static bool IsStringNullOrEmpty(this object obj)
        {
            return obj == null ||
                   obj.ToString().Length == 0 ||
                   obj.ToString().Trim().Length == 0;
        }

        private static bool IsDateTime(this object obj)
        {
            DateTime outObj;
            return DateTime.TryParse(obj.ToString(), out outObj);
        }

        public static bool IsDateTimeNull(this object obj)
        {
            try
            {
                if (obj == null) return true;
                var val = obj.ToString();
                if (obj.IsDateTime() && val.Trim() == string.Empty) return true;
                if (obj.IsDateTime() && Convert.ToDateTime(obj) == DateTime.MinValue) return true;
                if (obj.IsDateTime() && val.IndexOf("1/1/1900", StringComparison.Ordinal) > -1) return true;
                if (obj.IsDateTime() && val.IndexOf("01/01/1900", StringComparison.Ordinal) > -1) return true;
                if (obj.IsDateTime() && val.IndexOf("1/1/1753", StringComparison.Ordinal) > -1) return true;
                return false;
            }
            catch
            {
                return false;
            }
        }

        public static bool ToBoolean(this object source)
        {
            if (source.IsStringNullOrEmpty()) return false;

            bool value;
            return bool.TryParse(source.ToString(), out value) && value;
        }

        public static DateTime ToDateTime(this object source, string format = "dd/MM/yyyy hh:mm:ss")
        {
            if (source is DateTime)
                return (DateTime)source;

            return source.IsStringNullOrEmpty()
                       ? default(DateTime)
                       : DateTime.ParseExact(source.ToString(), format, CultureInfo.InvariantCulture);
        }

        public static string GetDescription(this object value, string unknown = "Unknown")
        {
            try
            {
                var fi = value.GetType().GetField(value.ToString());
                var attributes = (DescriptionAttribute[])fi.GetCustomAttributes(typeof(DescriptionAttribute), false);
                return (attributes.Length > 0) ? attributes[0].Description : string.Empty;
            }
            catch (Exception)
            {
                return unknown;
                //return string.Empty;
            }
        }

        public static string ConvertToUnSign(this string s)
        {
            if (String.IsNullOrEmpty(s))
                return "";
            else
            {
                Regex regex = new Regex("\\p{IsCombiningDiacriticalMarks}+");
                string temp = s.Normalize(NormalizationForm.FormD);
                return regex.Replace(temp, String.Empty).Replace('\u0111', 'd').Replace('\u0110', 'D');
            }
        }
    }
}