﻿using Microsoft.Extensions.Caching.Distributed;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using StackExchange.Redis.Extensions.Core;
using StackExchange.Redis.Extensions.Core.Abstractions;

namespace SSI.RPA.Common
{
    public static class CacheExtensions
    {
        #region Microsoft Redis Cache
        public static T Get<T>(this IDistributedCache cache, string key)
        {
            try
            {
                var result = cache.GetString(key);
                return JsonConvert.DeserializeObject<T>(result);
            }
            catch
            {
                return default(T);
            }
        }

        public static async Task<T> GetAsync<T>(this IDistributedCache cache, string key, CancellationToken token = default)
        {
            try
            {
                var result = await cache.GetStringAsync(key, token);
                return JsonConvert.DeserializeObject<T>(result);
            }
            catch
            {
                return default(T);
            }
        }


        public static async Task SetAsync<T>(this IDistributedCache cache, string key, T value, DistributedCacheEntryOptions options = null, CancellationToken token = default)
        {
            if (options == null)
            {
                options = new DistributedCacheEntryOptions().SetSlidingExpiration(TimeSpan.FromDays(1));
            }
            var cacheValue = JsonConvert.SerializeObject(value);

            await cache.SetStringAsync(key, cacheValue, options, token);
        }

        public static void Set<T>(this IDistributedCache cache, string key, T value, DistributedCacheEntryOptions options = null)
        {
            try
            {
                if (options == null)
                {
                    options = new DistributedCacheEntryOptions().SetSlidingExpiration(TimeSpan.FromDays(1));
                }
                var cacheValue = JsonConvert.SerializeObject(value);

                cache.Set(key, value, options);
            }
            catch (Exception ex)
            {
            }
        }
        #endregion

        #region StackExchange Redis

        public static async Task SESetAsync<T>(this IRedisCacheClient cache, string key, T value, DateTimeOffset dateTimeOffset = default(DateTimeOffset))
        {
            if (dateTimeOffset == default(DateTimeOffset))
            {
                dateTimeOffset = DateTimeOffset.Now.AddDays(1);
            }
            await cache.GetDbFromConfiguration().AddAsync(key, value, dateTimeOffset);
        }

        public static async Task<T> SEGetAsync<T>(this IRedisCacheClient cache, string key)
        {
            return await cache.GetDbFromConfiguration().GetAsync<T>(key);
        }

        public static async Task<bool> SERemoveAsync(this IRedisCacheClient cache, string key)
        {
            return await cache.GetDbFromConfiguration().RemoveAsync(key);
        }

        public static async Task SERemovePatternAsync(this IRedisCacheClient cache, string key)
        {
            var keysCache = await cache.GetDbFromConfiguration().SearchKeysAsync(key + "*");
            foreach (var keyCache in keysCache)
                await cache.GetDbFromConfiguration().RemoveAsync(keyCache);
        }

        #endregion

    }
}
