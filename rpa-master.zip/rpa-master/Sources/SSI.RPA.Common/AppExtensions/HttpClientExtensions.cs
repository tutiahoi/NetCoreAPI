using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Text;
using System.Net;
using System;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Primitives;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Collections.Generic;

namespace SSI.RPA.Common
{
    public class JsonResultModel<TData>
    {
        public int StatusCode { get; set; } = (int)HttpStatusCode.OK;
        public string Message { get; set; } = "";
        public TData Data { get; set; }

        public JsonResultModel(TData data)
        {
            Data = data;
        }

        public override string ToString()
        {
            return JsonConvert.SerializeObject(this);
        }
    }

    public static class HttpClientExtensions
    {
        public static async Task<JsonResultModel<T>> GetJsonAsync<T>(this HttpClient httpClient, string requestUri)
            where T : new()
        {
            try
            {
                var stringContent = await httpClient.GetStringAsync(requestUri);
                var resData = JsonConvert.DeserializeObject<T>(stringContent, new JsonSerializerSettings() { });
                var result = new JsonResultModel<T>(resData);
                return result;
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("401 (Unauthorized)"))
                    throw new Exception("401");
                if (ex.Message.Contains("403"))
                    throw new Exception("403");
                else
                {
                    var resData = JsonConvert.DeserializeObject<T>("{\"Status\":" + (ex.Message.Contains("403") ? "-403" : "-1") + ",\"Errors\":{\"ErrorMessage\":[\"" + ex.Message + "\"]}}");
                    var result = new JsonResultModel<T>(resData);
                    result.StatusCode = (int)HttpStatusCode.InternalServerError;
                    result.Message = ex.Message;
                    return result;
                }
            }
        }
        public static JsonResultModel<T> GetJsonNotAsync<T>(this HttpClient httpClient, string requestUri)
              where T : new()
        {
            try
            {
                var stringContent = httpClient.GetStringAsync(requestUri).Result;
                var resData = JsonConvert.DeserializeObject<T>(stringContent, new JsonSerializerSettings() { }); ;
                var result = new JsonResultModel<T>(resData);
                return result;
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("401 (Unauthorized)"))
                    throw new Exception("401");
                else
                {
                    var resData = JsonConvert.DeserializeObject<T>("{\"Status\":" + (ex.Message.Contains("403") ? "-403" : "-1") + ",\"Errors\":{\"ErrorMessage\":[\"" + ex.Message + "\"]}}");
                    var result = new JsonResultModel<T>(resData);
                    result.StatusCode = (int)HttpStatusCode.InternalServerError;
                    result.Message = ex.Message;
                    return result;
                }
            }
        }
        public static async Task<JsonResultModel<T>> PostJsonAsync<T>(this HttpClient httpClient, string requestUri, object content)
            where T : new()
        {
            try
            {
                var contentJson = JsonConvert.SerializeObject(content);
                var response = await httpClient.SendAsync(new HttpRequestMessage(HttpMethod.Post, requestUri)
                {
                    Content = new StringContent(contentJson.ToString(), Encoding.UTF8, "application/json")
                });

                response.EnsureSuccessStatusCode();

                if (typeof(JsonResultModel<T>) == typeof(IgnoreResponse))
                {
                    return default;
                }
                else
                {
                    var resData = JsonConvert.DeserializeObject<T>(await response.Content.ReadAsStringAsync(), new JsonSerializerSettings() { });
                    var resultModel = new JsonResultModel<T>(resData);
                    return resultModel;
                }
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("401 (Unauthorized)"))
                    throw new Exception("401");
                if (ex.Message.Contains("403"))
                    throw new Exception("403");
                else
                {
                    var resData = JsonConvert.DeserializeObject<T>("{\"Status\":" + (ex.Message.Contains("403") ? "-403" : "-1") + ",\"Errors\":{\"ErrorMessage\":[\"" + ex.Message + "\"]}}");
                    var result = new JsonResultModel<T>(resData);
                    result.StatusCode = (int)HttpStatusCode.InternalServerError;
                    result.Message = ex.Message;
                    return result;
                }
            }

        }
        public static JsonResultModel<T> PostJsonNotAsync<T>(this HttpClient httpClient, string requestUri, object content)
            where T : new()
        {
            try
            {
                var contentJson = JsonConvert.SerializeObject(content);
                var response = httpClient.SendAsync(new HttpRequestMessage(HttpMethod.Post, requestUri)
                {
                    Content = new StringContent(contentJson.ToString(), Encoding.UTF8, "application/json")
                }).Result;

                response.EnsureSuccessStatusCode();

                if (typeof(JsonResultModel<T>) == typeof(IgnoreResponse))
                {
                    return default;
                }
                else
                {
                    var resData = JsonConvert.DeserializeObject<T>(response.Content.ReadAsStringAsync().Result, new JsonSerializerSettings() { });
                    var resultModel = new JsonResultModel<T>(resData);
                    return resultModel;
                }
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("401 (Unauthorized)"))
                    throw new Exception("401");
                else
                {
                    var resData = JsonConvert.DeserializeObject<T>("{\"Status\":" + (ex.Message.Contains("403") ? "-403" : "-1") + ",\"Errors\":{\"ErrorMessage\":[\"" + ex.Message + "\"]}}");
                    var result = new JsonResultModel<T>(resData);
                    result.StatusCode = (int)HttpStatusCode.InternalServerError;
                    result.Message = ex.Message;
                    return result;
                }
            }

        }
        public static async Task SetBearToken(this HttpClient httpClient, string access_token)
        {
            httpClient.DefaultRequestHeaders.Accept.Add(
            new MediaTypeWithQualityHeaderValue("application/json"));
            httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", access_token);
        }

        public static void SetBearTokenFromRequestHeader(this HttpClient httpClient, IHttpContextAccessor httpContextAccessor)
        {
            StringValues authToken = new StringValues();
            httpContextAccessor.HttpContext.Request.Headers.TryGetValue("Authorization", out authToken);
            if (authToken.ToString() != string.Empty)
            {
                authToken = authToken.ToString().Replace("Bearer ", "");
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", authToken);
            }
        }

        public static void AttachPermissionAction(this HttpClient httpClient, int permissionId, int actionId)
        {
            httpClient.DefaultRequestHeaders.Remove("PermissionID");
            httpClient.DefaultRequestHeaders.Remove("ActionID");

            httpClient.DefaultRequestHeaders.Add("PermissionID", permissionId.ToString());
            httpClient.DefaultRequestHeaders.Add("ActionID", actionId.ToString());
        }

        public static void AttachUserinfo(this HttpClient httpClient, string userinfo)
        {
            httpClient.DefaultRequestHeaders.Remove("UserInfo");
            httpClient.DefaultRequestHeaders.Add("UserInfo", userinfo);
        }

        public static string TryGetTokenUserID(this HttpContext httpContext)
        {
            try
            {
                StringValues authToken = new StringValues();
                httpContext.Request.Headers.TryGetValue("Authorization", out authToken);
                authToken = authToken.ToString().Replace("Bearer ", "");
                var handler = new JwtSecurityTokenHandler();
                var token = handler.ReadToken(authToken) as JwtSecurityToken;

                if (token != null)
                {
                    return token.Claims.First(claim => claim.Type == "sub").Value;
                }
                else
                    return "";
            }
            catch
            {
                return "";
            }
        }

        public static string TryGetUserInfo(this HttpContext httpContext)
        {
            try
            {
                StringValues userInfo = new StringValues();
                httpContext.Request.Headers.TryGetValue("UserInfo", out userInfo);

                return userInfo.ToString();
            }
            catch
            {
                return "";
            }
        }

        public static string TryGetPermission(this HttpContext httpContext)
        {
            try
            {
                StringValues permissionId = new StringValues();
                httpContext.Request.Headers.TryGetValue("PermissionID", out permissionId);

                return permissionId.ToString();
            }
            catch
            {
                return "";
            }
        }

        public static string TryGetAction(this HttpContext httpContext)
        {
            try
            {
                StringValues action = new StringValues();
                httpContext.Request.Headers.TryGetValue("ActionID", out action);

                return action.ToString();
            }
            catch
            {
                return "";
            }
        }

        public static string TryGetZones(this HttpContext httpContext)
        {
            try
            {
                StringValues zone = new StringValues();
                httpContext.Request.Headers.TryGetValue("Zones", out zone);

                return zone.ToString();
            }
            catch
            {
                return "";
            }
        }

        class IgnoreResponse { }
    }
}
