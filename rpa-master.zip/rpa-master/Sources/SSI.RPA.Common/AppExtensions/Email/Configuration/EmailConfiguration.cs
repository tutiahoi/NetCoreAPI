﻿using System.Net;

namespace SSI.RPA.Common.Email.Configuration
{
    public class EmailConfiguration
    {
        public EmailConfiguration() { }

        public string SmtpServer { get; set; }
        public bool Authentication { get; set; }
        public bool EnableSSL { get; set; }

        public string SmtpUserName { get; set; }
        public string SmtpPassword { get; set; }

        public string From { get; set; }

        public string SenderName { get; set; }
    }
}
