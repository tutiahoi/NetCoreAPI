﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using SSI.RPA.Common.Email.Configuration;
using SSI.RPA.Common.Email.Service;

namespace SSI.RPA.Common.Email
{
    public static class EmailInstaller
    {
        public static IServiceCollection AddEmailConfiguration(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddSingleton(new EmailConfiguration
            {
                SmtpServer = configuration.GetValue<string>("Email:SmtpServer"),
                SmtpUserName = configuration.GetValue<string>("Email:SmtpUserName"),
                SmtpPassword = configuration.GetValue<string>("Email:SmtpPassword"),
                Authentication = configuration.GetValue<bool>("Email:Authentication"),
                EnableSSL = configuration.GetValue<bool>("Email:EnableSSL"),
                From = configuration.GetValue<string>("Email:From"),
                SenderName = configuration.GetValue<string>("Email:SenderName")
            });

            services.AddSingleton<IEmailService, EMailService>();

            return services;
        }
    }
}
