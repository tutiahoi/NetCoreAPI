﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SSI.RPA.Common.Email.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;

namespace SSI.RPA.Common.Email.Service
{
    public class EMailService : IEmailService
    {
        private const string SEPARATOR = "|";
        private const string SEPARATOR2 = ";";
        private const string SEPARATOR3 = ",";
        private SmtpClient _client = null;
        private string _from = "";
        private string _senderName = "";
        private readonly ILogger<EMailService> _logger;

        /// <summary>
        /// 
        /// </summary>
        public EMailService(EmailConfiguration config, ILogger<EMailService> logger)
        {
            _client = new SmtpClient(config.SmtpServer);
            _from = config.From;
            _senderName = config.SenderName;
            if (config.Authentication)
            {
                _client = new SmtpClient(config.SmtpServer);
                _client.UseDefaultCredentials = false;
                NetworkCredential credential = new NetworkCredential(config.SmtpUserName, config.SmtpPassword);
                _client.Credentials = credential;
            }

            if (config.EnableSSL)
            {
                _client.EnableSsl = true;
            }

            _logger = logger;
        }

        public async Task SendMail(string subject, string body, string to)
        {
            await SendMail(subject, body, _from, to, _senderName);
        }

        public async Task SendMail(string subject, AlternateView alternateView, string to)
        {
            await SendMailTemp(subject, alternateView, _from, to, _senderName, null);
        }

        public async Task SendMail(string subject, AlternateView alternateView, string to, Dictionary<string, byte[]> files)
        {
            await SendMailTemp(subject, alternateView, _from, to, _senderName, files);
        }

        public async Task SendMail(string subject, string body, string from, string to)
        {
            await SendMail(subject, body, from, to, null);
        }
        public async Task SendMail(string subject, string body, string from, string to, string senderName)
        {
            await SendMail(subject, body, from, to, senderName, null);
        }
        public async Task SendMail(string subject, string body, string from, string to, string senderName, string[] files)
        {
            await SendMail(subject, body, from, to, senderName, files, MediaTypeNames.Application.Octet);
        }

        public async Task SendMailTemp(string subject, AlternateView alternateView, string from, string to, string senderName, Dictionary<string, byte[]> files)
        {
            await SendMailtemplate(subject, alternateView, from, to, senderName, files);
        }   

        public async Task SendMail(string subject, string body, string from, string to, string senderName, string[] files, string filetype)
        {
            await Task.Run(() =>
            {
                MailAddress _from;
                if (!string.IsNullOrEmpty(senderName))
                    _from = new MailAddress(from, senderName);
                else
                    _from = new MailAddress(from);
                MailMessage message = new MailMessage();
                string separator = GetSeparator(to);
                string[] tolist = to.Split(separator.ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
                for (int i = 0; i < tolist.Length; i++)
                {
                    message.To.Add(new MailAddress(tolist[i]));
                }

                message.From = _from;
                message.Sender = _from;
                message.Subject = subject;
                message.Body = body;
                message.IsBodyHtml = true;

                if (files != null)
                {
                    foreach (string file in files)
                    {
                        if (!string.IsNullOrEmpty(file))
                        {
                            Attachment attach = new Attachment(file, filetype);
                            message.Attachments.Add(attach);
                        }
                    }
                }

                try
                {
                    _client.Send(message);
                }
                catch (Exception ex)
                {
                    int retry = 1;
                    while (retry <= 3)
                    {
                        try
                        {
                            _client.Send(message);
                            break;
                        }
                        catch (Exception ex1)
                        {
                            retry++;
                            Thread.Sleep(3000);
                        }
                    }
                }

            });
        }

        public async Task SendMailtemplate(string subject, AlternateView alternateView, string from, string to, string senderName, Dictionary<string, byte[]> files)
        {
            await Task.Run(() =>
            {
                MailAddress _from;
                if (!string.IsNullOrEmpty(_senderName))
                    _from = new MailAddress(from, _senderName);
                else
                    _from = new MailAddress(from);
                MailMessage message = new MailMessage();
                string separator = GetSeparator(to);
                string[] tolist = to.Split(separator.ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
                for (int i = 0; i < tolist.Length; i++)
                {
                    message.To.Add(new MailAddress(tolist[i]));
                }

                message.From = _from;
                message.Sender = _from;
                message.Subject = subject;
                message.AlternateViews.Add(alternateView);
                message.IsBodyHtml = true;

                if (files != null && files.Count > 0)
                {
                    foreach(var file in files)
                    {
                        Attachment attach = new Attachment(new MemoryStream(file.Value), file.Key);
                        message.Attachments.Add(attach);
                    }                  
                }

                try
                {
                    _client.Send(message);
                }
                catch (Exception ex)
                {
                    var logInfo = $"From: {from} To: {to} Subject: {subject} Body: {alternateView.ToString()}";
                    _logger.LogWarning($"[EmailService] {logInfo} Error: {ex.ToString()}");

                    int retry = 1;
                    while (retry <= 3)
                    {
                        _logger.LogWarning($"[EmailService] Thực hiện Retry lần {retry} với {logInfo}");

                        try
                        {
                            _client.Send(message);
                            break;
                        }
                        catch (Exception ex1)
                        {
                            retry++;
                            _logger.LogWarning($"[EmailService] {logInfo} Error: {ex1.ToString()}");
                            Thread.Sleep(3000);
                        }
                    }
                }
            });
        }

        private void AddRecipients(MailAddressCollection addresses, string to)
        {
            if (!string.IsNullOrEmpty(to))
            {
                string[] tolist = to.Split(SEPARATOR.ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
                addresses = new MailAddressCollection();
                for (int i = 0; i < tolist.Length; i++)
                {
                    addresses.Add(new MailAddress(tolist[i]));
                }
            }
        }

        private string GetSeparator(string addresses)
        {
            if (addresses.IndexOf(SEPARATOR) > -1)
                return SEPARATOR;
            else if (addresses.IndexOf(SEPARATOR2) > -1)
                return SEPARATOR2;
            else
                return SEPARATOR3;
        }
    }
}
