﻿using System;
using System.Collections.Generic;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace SSI.RPA.Common.Email.Service
{
    public interface IEmailService
    {
        Task SendMail(string subject, string body, string to);

        Task SendMail(string subject, AlternateView alternateView, string to);

        Task SendMail(string subject, AlternateView alternateView, string to, Dictionary<string, byte[]> files);        

        Task SendMail(string subject, string body, string from, string to);

        Task SendMail(string subject, string body, string from, string to, string senderName);

        Task SendMail(string subject, string body, string from, string to, string senderName, string[] files);
    }
}
