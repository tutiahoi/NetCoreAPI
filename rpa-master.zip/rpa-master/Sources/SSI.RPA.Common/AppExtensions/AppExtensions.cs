﻿using Consul;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using StackExchange.Redis.Extensions.Core;
using StackExchange.Redis.Extensions.Core.Abstractions;
using StackExchange.Redis.Extensions.Core.Configuration;
using StackExchange.Redis.Extensions.Core.Implementations;
using StackExchange.Redis.Extensions.Newtonsoft;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SSI.RPA.Common
{
    public static class AppExtensions
    {
        public static IServiceCollection AddConsul(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddSingleton<IConsulClient, ConsulClient>(p => new ConsulClient(consulConfig =>
            {
                //consul address  
                var address = configuration.GetValue<string>("ConsulHost");
                consulConfig.Address = new Uri(address);
            }));

            return services;
        }
        
        public static IServiceCollection AddRedisCache(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddSingleton(new RedisConfiguration
            {
                ConnectTimeout = configuration.GetValue<int>("Redis:ConnectTimeout"),
                Hosts = new RedisHost[] {
                            new RedisHost{
                                Host = configuration.GetValue<string>("Redis:Hosts:0:Host"),
                                Port = configuration.GetValue<int>("Redis:Hosts:0:Port")
                            }},
                Database = configuration.GetValue<int>("Redis:Database"),
                Password = configuration.GetValue<string>("Redis:Password"),
                AllowAdmin = configuration.GetValue<bool>("Redis:AllowAdmin"),
                Ssl = configuration.GetValue<bool>("Redis:Ssl"),
                SyncTimeout = configuration.GetValue<int>("Redis:SyncTimeout"),

            });
            services.AddSingleton<IRedisCacheClient, RedisCacheClient>();
            services.AddSingleton<IRedisCacheConnectionPoolManager, RedisCacheConnectionPoolManager>();
            services.AddSingleton<IRedisDefaultCacheClient, RedisDefaultCacheClient>();
            services.AddSingleton<ISerializer, NewtonsoftSerializer>();

            return services;
        }

        public static IApplicationBuilder UnregToConsul(this IApplicationBuilder app, IConfiguration configuration)
        {
            var consulClient = app.ApplicationServices.GetRequiredService<IConsulClient>();
            var logger = app.ApplicationServices.GetRequiredService<ILoggerFactory>().CreateLogger("AppExtensions");

            var regInfo = new ServiceRegInfo
            {
                ServiceRegName = configuration.GetValue<string>("Consul:ServiceRegName"),
                ServiceRegID = configuration.GetValue<string>("Consul:ServiceRegID"),
                ServiceRegIP = configuration.GetValue<string>("Consul:ServiceRegIP"),
                ServiceRegPort = configuration.GetValue<int>("Consul:ServiceRegPort"),
                ServiceRegTags = configuration.GetValue<string>("Consul:ServiceRegTags").Split('|'),
                ServiceHealthCheckTCP = configuration.GetValue<bool>("Consul:ServiceHealthCheckTCP"),
                ServiceHealthCheckHTTP = configuration.GetValue<bool>("Consul:ServiceHealthCheckHTTP")
            };

            var registration = new AgentServiceRegistration()
            {
                ID = $"{regInfo.ServiceRegID}-{regInfo.ServiceRegPort}",
                Name = $"{regInfo.ServiceRegName}",
                Address = $"{regInfo.ServiceRegIP}",
                Port = regInfo.ServiceRegPort,
                Tags = regInfo.ServiceRegTags
            };

            List<AgentServiceCheck> agentServiceChecks = new List<AgentServiceCheck>();

            if (regInfo.ServiceHealthCheckTCP)
            {
                var tcpCheck = new AgentServiceCheck()
                {
                    Interval = TimeSpan.FromSeconds(30),
                    TCP = $"{regInfo.ServiceRegIP}:{regInfo.ServiceRegPort}"
                };
                agentServiceChecks.Add(tcpCheck);
            }

            if (regInfo.ServiceHealthCheckHTTP)
            {
                var httpCheck = new AgentServiceCheck()
                {
                    Interval = TimeSpan.FromSeconds(30),
                    HTTP = $"http://{regInfo.ServiceRegIP}:{regInfo.ServiceRegPort}/HealthCheck"
                };
                agentServiceChecks.Add(httpCheck);
            }

            if (agentServiceChecks.Any())
            {
                registration.Checks = agentServiceChecks.ToArray();
            }

            logger.LogInformation("Unregistering from Consul");
            consulClient.Agent.ServiceDeregister(registration.ID).ConfigureAwait(true);

            return app;
        }

        public static IApplicationBuilder RegToConsul(this IApplicationBuilder app, IConfiguration configuration)
        {
            var consulClient = app.ApplicationServices.GetRequiredService<IConsulClient>();
            var logger = app.ApplicationServices.GetRequiredService<ILoggerFactory>().CreateLogger("AppExtensions");
            var lifetime = app.ApplicationServices.GetRequiredService<IApplicationLifetime>();

            var regInfo = new ServiceRegInfo
            {
                ServiceRegName = configuration.GetValue<string>("Consul:ServiceRegName"),
                ServiceRegID = configuration.GetValue<string>("Consul:ServiceRegID"),
                ServiceRegIP = configuration.GetValue<string>("Consul:ServiceRegIP"),
                ServiceRegPort = configuration.GetValue<int>("Consul:ServiceRegPort"),
                ServiceRegTags = configuration.GetValue<string>("Consul:ServiceRegTags").Split('|'),
                ServiceHealthCheckTCP = configuration.GetValue<bool>("Consul:ServiceHealthCheckTCP"),
                ServiceHealthCheckHTTP = configuration.GetValue<bool>("Consul:ServiceHealthCheckHTTP")
            };

            var registration = new AgentServiceRegistration()
            {
                ID = $"{regInfo.ServiceRegID}-{regInfo.ServiceRegPort}",
                Name = $"{regInfo.ServiceRegName}",
                Address = $"{regInfo.ServiceRegIP}",
                Port = regInfo.ServiceRegPort,
                Tags = regInfo.ServiceRegTags
            };

            List<AgentServiceCheck> agentServiceChecks = new List<AgentServiceCheck>();

            if (regInfo.ServiceHealthCheckTCP)
            {
                var tcpCheck = new AgentServiceCheck()
                {
                    Interval = TimeSpan.FromSeconds(30),
                    TCP = $"{regInfo.ServiceRegIP}:{regInfo.ServiceRegPort}"
                };
                agentServiceChecks.Add(tcpCheck);
            }

            if (regInfo.ServiceHealthCheckHTTP)
            {
                var httpCheck = new AgentServiceCheck()
                {
                    Interval = TimeSpan.FromSeconds(30),
                    HTTP = $"http://{regInfo.ServiceRegIP}:{regInfo.ServiceRegPort}/HealthCheck"
                };
                agentServiceChecks.Add(httpCheck);
            }

            if (agentServiceChecks.Any())
            {
                registration.Checks = agentServiceChecks.ToArray();
            }

            logger.LogInformation("Registering with Consul");
            consulClient.Agent.ServiceDeregister(registration.ID).ConfigureAwait(true);
            consulClient.Agent.ServiceRegister(registration).ConfigureAwait(true);

            lifetime.ApplicationStopped.Register(() =>
            {
                logger.LogInformation("Unregistering from Consul");
                consulClient.Agent.ServiceDeregister(registration.ID).ConfigureAwait(true);
            });

            return app;
        }
    }
}
