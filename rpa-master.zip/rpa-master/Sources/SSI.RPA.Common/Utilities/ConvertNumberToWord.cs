﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace SSI.RPA.Common.Utilities
{
    public class ConvertNumberToWord
    {
        public ConvertNumberToWord()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        /// <summary>
        /// Ham Convert chung cho da ngu
        /// </summary>
        #region static public string ToString(string number)
        static public string ToString(string number)
        {
            string resultString = "";
            string cNumber = "";


            switch (Thread.CurrentThread.CurrentCulture.Name)
            {

                case "vi-VN":
                    cNumber = number.Replace(" ", "");
                    resultString = nhieuso(cNumber);
                    break;
                case "en-US":
                    cNumber = number.Replace(",", "");
                    resultString = changeNumericToWords(cNumber);
                    break;
                default:
                    break;
            }
            resultString = resultString.Substring(0, 1).ToUpper() + resultString.Substring(1, resultString.Length - 1);
            return resultString;
        }
        #endregion


        /// <summary>
        /// Convert Tieng Viet
        /// </summary>
        #region Các hàm đọc số tieng Viet
        static public string motso(string bienso)
        {
            switch (bienso)
            {
                case "0": return "không";
                case "1": return "một";
                case "2": return "hai";
                case "3": return "ba";
                case "4": return "bốn";
                case "5": return "năm";
                case "6": return "sáu";
                case "7": return "bảy";
                case "8": return "tám";
                case "9": return "chín";
            }
            return "không";
        }
        static public string haiso(string bienso)
        {
            string biendoc = " mười ";
            if ((bienso.Substring(1, 1) == "0") && (bienso.Substring(0, 1) != "1")) biendoc = motso(bienso.Substring(0, 1)) + " mươi ";
            if (bienso.Substring(1, 1) != "0")
                switch (bienso.Substring(1, 1))
                {
                    case "5":
                        if (bienso.Substring(0, 1) == "1") biendoc = " mười lăm";
                        else biendoc = motso(bienso.Substring(0, 1)) + " mươi lăm";
                        break;
                    case "1":
                        if (bienso.Substring(0, 1) == "1") biendoc = " mười một";
                        else biendoc = motso(bienso.Substring(0, 1)) + " mươi mốt";
                        break;
                    default:
                        if (bienso.Substring(0, 1) == "1") biendoc = " mười " + motso(bienso.Substring(1, 1));
                        else biendoc = motso(bienso.Substring(0, 1)) + " mươi " + motso(bienso.Substring(1, 1));
                        break;
                }

            return biendoc;
        }
        static public string baso(string bienso)
        {
            string biendoc = "trăm";
            if (bienso.Substring(1, 1) == "0")
            {
                if (bienso.Substring(2, 1) == "0") biendoc = motso(bienso.Substring(0, 1)) + " trăm ";
                else biendoc = motso(bienso.Substring(0, 1)) + " trăm lẻ " + motso(bienso.Substring(2, 1));
            }
            else
            {
                biendoc = motso(bienso.Substring(0, 1)) + " trăm " + haiso(bienso.Substring(1, 2));
            }
            return biendoc;
        }

        // hàm xử lý vấn đề số 0
        static public string xoasokhong(string tam)
        {
            while (tam[0] == '0')
            {
                if (tam.Length > 1) tam = tam.Substring(1, tam.Length - 1);
                else break;
            }
            return tam;
        }
        // hàm xử lý chèn các giá trị 
        static public string kieuchen(int tam)
        {
            switch (tam)
            {
                case 0: return " đồng ";
                case 1: return " nghìn ";
                case 2: return " triệu ";
                case 3: return " tỷ ";
            }
            return "";
        }
        // hàm đọc nhiều số
        static public string nhieuso(string so)
        {
            int dodai = so.Length - 3;
            string bienso = so.Substring(0, dodai);

            string hao = so.Substring(dodai + 1, 1);
            string xu = so.Substring(dodai + 2, 1);

            string biendoc = "", bientam = "";
            int i = 0;
            while ((dodai) > 3)
            {

                bientam = baso(bienso.Substring(bienso.Length - 3, 3));
                bienso = bienso.Substring(0, bienso.Length - 3);
                biendoc = bientam + kieuchen(i) + biendoc;
                i++;
                if (i > 3) i = 1;
                if (dodai > 3) dodai = dodai - 3;
            }
            if (dodai == 1) biendoc = motso(bienso) + kieuchen(i) + biendoc;
            if (dodai == 2) biendoc = haiso(bienso) + kieuchen(i) + biendoc;
            if (dodai == 3) biendoc = baso(bienso) + kieuchen(i) + biendoc;

            string resultWord = "";
            if ((hao == "0") && (xu == "0"))
                resultWord = biendoc + " chẵn";
            else if (hao == "0")
                resultWord = biendoc + " " + xu + " xu";
            else if (xu == "0")
                resultWord = biendoc + " " + hao + " hào";
            else
                resultWord = biendoc + " " + hao + " hào " + xu + " xu";

            return resultWord;
        }
        #endregion

        /// <summary>
        /// Convert Tieng Anh
        /// </summary>
        #region Các hàm đọc số tieng Anh

        static public String changeNumericToWords(double numb)
        {
            String num = numb.ToString();
            return changeToWords(num, false);
        }

        static public String changeCurrencyToWords(String numb)
        {
            return changeToWords(numb, true);
        }

        static public String changeNumericToWords(String numb)
        {
            return changeToWords(numb, false);
        }

        static public String changeCurrencyToWords(double numb)
        {
            string Words = changeToWords(numb.ToString(), true);
            if (Words.Length > 0) Words = Words.Substring(0, 1).ToUpper() + Words.Substring(1, Words.Length - 1);
            return Words;
        }

        static public String changeToWords(String numb, bool isCurrency)
        {
            String val = "", wholeNo = numb, points = "", andStr = "", pointStr = "";
            String endStr = (isCurrency) ? ("only") : ("");
            try
            {
                int decimalPlace = numb.IndexOf(".");
                if (decimalPlace > 0)
                {
                    wholeNo = numb.Substring(0, decimalPlace);
                    points = numb.Substring(decimalPlace + 1);
                    if (Convert.ToInt32(points) > 0)
                    {
                        andStr = (isCurrency) ? ("and") : ("point");// just to separate whole numbers from points/cents
                        endStr = (isCurrency) ? ("Cents " + endStr) : ("");
                        pointStr = translateCents(points);
                    }
                }
                val = String.Format("{0} {1}{2} {3}", translateWholeNumber(wholeNo).Trim(), andStr, pointStr, endStr);
            }
            catch {; }
            return val;
        }

        static public String translateWholeNumber(String number)
        {
            string word = "";
            try
            {
                bool beginsZero = false;//tests for 0XX
                bool isDone = false;//test if already translated
                double dblAmt = (Convert.ToDouble(number));
                //if ((dblAmt > 0) && number.StartsWith("0"))

                if (dblAmt > 0)
                {//test for zero or digit zero in a nuemric

                    beginsZero = number.StartsWith("0");
                    int numDigits = number.Length;
                    int pos = 0;//store digit grouping
                    String place = "";//digit grouping name:hundres,thousand,etc...

                    switch (numDigits)
                    {
                        case 1://ones' range
                            word = ones(number);
                            isDone = true;
                            break;

                        case 2://tens' range
                            word = tens(number);
                            isDone = true;
                            break;

                        case 3://hundreds' range
                            pos = (numDigits % 3) + 1;
                            place = " hundred ";
                            break;

                        case 4://thousands' range

                        case 5:

                        case 6:
                            pos = (numDigits % 4) + 1;
                            place = " thousand ";
                            break;

                        case 7://millions' range

                        case 8:

                        case 9:

                            pos = (numDigits % 7) + 1;
                            place = " million ";
                            break;

                        case 10://Billions's range

                            pos = (numDigits % 10) + 1;
                            place = " billion ";
                            break;

                        //add extra case options for anything above Billion...

                        default:
                            isDone = true;
                            break;

                    }

                    if (!isDone)
                    {//if transalation is not done, continue...(Recursion comes in now!!)

                        word = translateWholeNumber(number.Substring(0, pos)) + place + translateWholeNumber(number.Substring(pos));

                        //check for trailing zeros

                        if (beginsZero) word = " and " + word.Trim();

                    }

                    //ignore digit grouping names

                    if (word.Trim().Equals(place.Trim())) word = "";

                }

            }

            catch {; }

            return word.Trim();

        }

        static public String tens(String digit)
        {

            int digt = Convert.ToInt32(digit);
            String name = null;
            switch (digt)
            {
                case 10:
                    name = "ten";
                    break;

                case 11:
                    name = "eleven";
                    break;

                case 12:
                    name = "twelve";
                    break;

                case 13:
                    name = "thirteen";
                    break;

                case 14:
                    name = "fourteen";
                    break;

                case 15:
                    name = "fifteen";
                    break;

                case 16:
                    name = "sixteen";
                    break;

                case 17:
                    name = "seventeen";
                    break;

                case 18:
                    name = "eighteen";
                    break;

                case 19:
                    name = "nineteen";
                    break;

                case 20:
                    name = "twenty";
                    break;

                case 30:
                    name = "thirty";
                    break;

                case 40:
                    name = "fourty";
                    break;

                case 50:
                    name = "fifty";
                    break;

                case 60:
                    name = "sixty";
                    break;

                case 70:
                    name = "seventy";
                    break;

                case 80:
                    name = "eighty";
                    break;

                case 90:
                    name = "ninety";
                    break;

                default:
                    if (digt > 0)
                    {
                        name = tens(digit.Substring(0, 1) + "0") + " " + ones(digit.Substring(1));
                    }
                    break;
            }
            return name;
        }

        static public String ones(String digit)
        {
            int digt = Convert.ToInt32(digit);
            String name = "";
            switch (digt)
            {
                case 1:
                    name = "one";
                    break;

                case 2:
                    name = "two";
                    break;

                case 3:
                    name = "three";
                    break;

                case 4:
                    name = "four";
                    break;

                case 5:
                    name = "five";
                    break;

                case 6:
                    name = "six";
                    break;

                case 7:
                    name = "seven";
                    break;

                case 8:
                    name = "eight";
                    break;

                case 9:
                    name = "nine";
                    break;
            }
            return name;

        }

        static public String translateCents(String cents)
        {

            String cts = "", digit = "", engOne = "";
            for (int i = 0; i < cents.Length; i++)
            {
                digit = cents[i].ToString();
                if (digit.Equals("0"))
                {
                    engOne = "zero";
                }
                else
                {
                    engOne = ones(digit);
                }
                cts += " " + engOne;
            }
            return cts;
        }


        static public String translateCurrencyToWords(long nNumber)
        {
            long CurrentNumber = nNumber;
            string sReturn = "";
            if (CurrentNumber >= 1000000000000)
            {
                sReturn = sReturn + " " + GetWord(CurrentNumber / 1000000000000, "Thousand");
                CurrentNumber = CurrentNumber % 1000000000000;
            }
            if (CurrentNumber >= 1000000000)
            {
                sReturn = sReturn + " " + GetWord(CurrentNumber / 1000000000, "Billion");
                CurrentNumber = CurrentNumber % 1000000000;
            }

            if (CurrentNumber >= 1000000)
            {
                sReturn = sReturn + " " + GetWord(CurrentNumber / 1000000, "Million");
                CurrentNumber = CurrentNumber % 1000000;
            }

            if (CurrentNumber >= 1000)
            {
                sReturn = sReturn + " " + GetWord(CurrentNumber / 1000, "Thousand");
                CurrentNumber = CurrentNumber % 1000;
            }
            if (CurrentNumber >= 100)
            {
                sReturn = sReturn + " " + GetWord(CurrentNumber / 100, "Hundred");
                CurrentNumber = CurrentNumber % 100;
            }
            if (CurrentNumber >= 20)
            {
                sReturn = sReturn + " " + GetWord(CurrentNumber, "");
                CurrentNumber = CurrentNumber % 10;
            }
            else if (CurrentNumber > 0)
            {
                sReturn = sReturn + " " + GetWord(CurrentNumber, "");
                CurrentNumber = 0;
            }
            sReturn = sReturn.Replace("  ", " ").Trim().ToLower();
            if (sReturn.Length > 0)
            {
                sReturn = sReturn.Substring(0, 1).ToUpper() + sReturn.Substring(1, sReturn.Length - 1) + " only";
            }
            return sReturn.Replace("  ", " ").Trim();
        }

        static private string GetWord(long nNumber, string sPrefix)
        {
            long nCurrentNumber = nNumber;
            string sReturn = "";
            while (nCurrentNumber > 0)
            {
                if (nCurrentNumber > 100)
                {
                    sReturn = sReturn + " " + GetWord(nCurrentNumber / 100, "Hundred");
                    nCurrentNumber = nCurrentNumber % 100;
                }
                else if (nCurrentNumber >= 20)
                {
                    sReturn = sReturn + " " + GetTwentyWord(nCurrentNumber / 10);
                    nCurrentNumber = nCurrentNumber % 10;
                }
                else
                {
                    sReturn = sReturn + " " + GetLessThanTwentyWord(nCurrentNumber);
                    nCurrentNumber = 0;
                }
            }
            sReturn = sReturn + " " + sPrefix;
            return sReturn;
        }

        static private string GetTwentyWord(long nNumber)
        {
            string sReturn = "";
            switch (nNumber)
            {
                case 2:
                    sReturn = "Twenty";
                    break;
                case 3:
                    sReturn = "Thirty";
                    break;
                case 4:
                    sReturn = "Forty";
                    break;
                case 5:
                    sReturn = "Fifty";
                    break;
                case 6:
                    sReturn = "Sixty";
                    break;
                case 7:
                    sReturn = "Seventy";
                    break;
                case 8:
                    sReturn = "Eighty";
                    break;
                case 9:
                    sReturn = "Ninety";
                    break;
            }
            return sReturn;
        }

        static private string GetLessThanTwentyWord(long nNumber)
        {
            string sReturn = "";
            switch (nNumber)
            {
                case 1:
                    sReturn = "One";
                    break;
                case 2:
                    sReturn = "Two";
                    break;
                case 3:
                    sReturn = "Three";
                    break;
                case 4:
                    sReturn = "Four";
                    break;
                case 5:
                    sReturn = "Five";
                    break;
                case 6:
                    sReturn = "Six";
                    break;
                case 7:
                    sReturn = "Seven";
                    break;
                case 8:
                    sReturn = "Eight";
                    break;
                case 9:
                    sReturn = "Nine";
                    break;
                case 10:
                    sReturn = "Ten";
                    break;
                case 11:
                    sReturn = "Eleven";
                    break;
                case 12:
                    sReturn = "Twelve";
                    break;
                case 13:
                    sReturn = "Thirteen";
                    break;
                case 14:
                    sReturn = "Forteen";
                    break;
                case 15:
                    sReturn = "Fifteen";
                    break;
                case 16:
                    sReturn = "Sixteen";
                    break;
                case 17:
                    sReturn = "Seventeen";
                    break;
                case 18:
                    sReturn = "Eighteen";
                    break;
                case 19:
                    sReturn = "Nineteen";

                    break;
            }
            return sReturn;
        }
        #endregion

        #region Read money number to string VND

        /// <summary>
        /// ham doc so tien sang chu
        /// </summary>
        /// <param name="n"></param>
        /// <returns></returns>
        public static string ReadMoneyToString(double n)
        {
            string strSo = n.ToString();
            int len = (int)strSo.Length / 3;
            if (len * 3 < strSo.Length) len++;
            string[] t = new string[len];
            int i = 0;
            while (strSo != "")
            {
                if (strSo.Length > 3)
                {
                    t[i] = strSo.Substring(strSo.Length - 3, 3);
                    strSo = strSo.Substring(0, strSo.Length - 3);
                }
                else
                {
                    t[i] = strSo;
                    strSo = "";
                }
                i++;
            }

            string str = "";
            string temp;
            for (i = t.Length - 1; i >= 0; i--)
            {
                temp = Doc3(t[i]);
                if (temp.Trim() != "")
                {
                    str += temp.Trim() + " " + DonVi(i + 1) + " ";
                }
            }
            if (str.Length > 1)
            {
                str = str.Substring(0, 1).ToUpper() + str.Substring(1, str.Length - 1);
            }
            if (str.Length >= 4)
                if (str.Substring(str.Length - 5, 4) != DonVi(1)) str = str + DonVi(1);
            return str.Trim();
        }

        public static string DonVi(int n)
        {
            string str = "";
            switch (n.ToString())
            {
                case "0":
                    str = "VN";
                    break;
                case "1":
                    str = "đồng";
                    break;
                case "2":
                    str = "nghìn";
                    break;
                case "3":
                    str = "triệu";
                    break;
                case "4":
                    str = "tỷ";
                    break;
                case "5":
                    str = "nghìn";
                    break;
            }
            return str;
        }

        public static string Doc3(string n)
        {
            string tram = string.Empty, chuc = string.Empty, dv = string.Empty;
            if (n.Length == 3)
            {
                tram = n[0].ToString();
                chuc = n[1].ToString();
                dv = n[2].ToString();
            }
            if (n.Length == 2)
            {
                chuc = n[0].ToString();
                dv = n[1].ToString();
            }
            if (n.Length == 1)
            {
                dv = n[0].ToString();
            }
            if (n != "000")
            {
                if (tram != "") tram = So(int.Parse(tram)) + " trăm";
                if (chuc != "")
                {
                    switch (chuc)
                    {
                        case "0":
                            if (dv != "0")
                            {
                                chuc = "lẻ"; dv = So(int.Parse(dv));
                            }
                            else
                            {
                                dv = "";
                                chuc = "";
                            }
                            break;
                        case "1":
                            chuc = "mười";
                            if (dv != "0")
                            {
                                if (dv == "5")
                                {
                                    dv = "lăm";
                                }
                                else
                                {                                    
                                    dv = So(double.Parse(dv));
                                }
                            }
                            else
                            {
                                dv = "";
                            }
                            break;
                        default:
                            chuc = So(int.Parse(chuc)) + " mươi";
                            if (dv == "5")
                            {
                                dv = "lăm";
                            }
                            else
                            {
                                if (dv != "0") { 
                                    if(dv == "1")
                                    {
                                        dv = "mốt";
                                    }else
                                    {
                                        dv = So(int.Parse(dv));
                                    }
                                } 
                                else dv = "";
                            }
                            //dv = So(int.Parse(dv));
                            break;
                    }
                }
                else
                {
                    if (chuc != "")
                    {
                        switch (chuc)
                        {
                            case "1":
                                chuc = " mươi";
                                if (dv != "0")
                                {
                                    if (dv == "5")
                                    {
                                        dv = "lăm";
                                    }
                                    else
                                    {
                                        dv = So(int.Parse(dv));
                                    }
                                }
                                break;
                            default:
                                chuc = So(int.Parse(chuc)) + " mươi";
                                if (dv == "5")
                                {
                                    dv = "lăm";
                                }
                                else
                                {
                                    dv = So(int.Parse(dv));
                                }
                                break;
                        }
                    }
                    else
                    {
                        dv = So(int.Parse(dv));
                    }
                }
            }
            else
            {
                tram = "";
                chuc = "";
                dv = "";
            }
            return tram + " " + chuc + " " + dv;
        }

        public static string So(double n)
        {
            string str = "";
            switch (n.ToString())
            {
                case "0":
                    str = "không";
                    break;
                case "1":
                    str = "một";
                    break;
                case "2":
                    str = "hai";
                    break;
                case "3":
                    str = "ba";
                    break;
                case "4":
                    str = "bốn";
                    break;
                case "5":
                    str = "năm";
                    break;
                case "6":
                    str = "sáu";
                    break;
                case "7":
                    str = "bảy";
                    break;
                case "8":
                    str = "tám";
                    break;
                case "9":
                    str = "chín";
                    break;
            }
            return str;
        }
        #endregion
    }
}
