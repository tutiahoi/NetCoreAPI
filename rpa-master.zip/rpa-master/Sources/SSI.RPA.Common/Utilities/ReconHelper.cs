﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace SSI.RPA.Common.Utilities
{
    public class ReconHelper
    {
        public static string HandleRemark(string remark)
        {
            try
            {
                string regex = @"(((?!([\\_]))([\D]))([\d]{6,7}((\-([0-9a-zA-Z]|){1})|())((\.[0-9a-zA-Z]{1})|())((\,)|([\s])|($)))|([Aa][Pp][Pp][Cc][Oo][Dd][\s][\d]{6,7}((\.[0-9a-zA-Z]{1})|())))|(003[Cc][\d]{6,7}((\.[0-9a-zA-Z]{1})|()))|((@[Vv][Aa]_9616)[\d]{6,7}((\.([0-9a-zA-Z]){1})|()))|(([Ff][Oo][\w\W]9616)[\d]{6,7}((\.([0-9a-zA-Z]){1})|()))";
                var regexValue = Regex.Matches(remark, regex);
                if (regexValue.Count > 0)
                {
                    string value = regexValue[0].ToString();
                    value = Regex.Replace(value, @"((003[Cc])|([Aa][Pp][Pp][Cc][Oo][Dd])|((@[Vv][Aa]_9616))|(([Ff][Oo][\w\W]9616))|(\D))", "");
                    return value;
                }
            }
            catch(Exception ex)
            {
            }
            
            return string.Empty;
        }
    }
}
