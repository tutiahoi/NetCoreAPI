﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Security.Cryptography;
using System.Drawing;
using System.IO;

namespace SSI.RPA.Common.Utilities
{
    public static class Common
    {
        #region email/mobile
        /// <summary>
        /// format ve dang 09xxxxxxxx
        /// </summary>
        /// <param name="mobile"></param>
        /// <returns></returns>
        public static string GetRegularMobile(string mobile)
        {
            if (mobile.StartsWith("84"))
                mobile = string.Format("0{0}", mobile.Substring(2, mobile.Length - 2));
            if (mobile.StartsWith("+84"))
                mobile = string.Format("0{0}", mobile.Substring(3, mobile.Length - 3));
            return mobile;
        }

        /// <summary>
        /// format ve dang 849xxxxxxxx
        /// </summary>
        /// <param name="mobile"></param>
        /// <returns></returns>
        public static string GetNationalMobile(string mobile)
        {
            if (mobile.StartsWith("0"))
                mobile = string.Format("84{0}", mobile.Substring(1, mobile.Length - 1));
            return mobile;
        }

        public static bool IsMobile(string input)
        {
            var isMobile = false;
            if (string.IsNullOrEmpty(input))
            {
                return isMobile;
            }
            isMobile = Regex.IsMatch(input, @"^((0|84|\+84)\d{9,10})$", RegexOptions.IgnoreCase);
            return isMobile;
        }

        public static bool IsEmail(string input)
        {
            var isEmail = false;
            if (string.IsNullOrEmpty(input))
            {
                return isEmail;
            }
            isEmail = Regex.IsMatch(input, @"^(?("")("".+?(?<!\\)""@)|(([0-9a-z]((\.(?!\.))|[-!#\$%&'\*\+/=\?\^`\{\}\|~\w])*)(?<=[0-9a-z])@))" +
                @"(?(\[)(\[(\d{1,3}\.){3}\d{1,3}\])|(([0-9a-z][-0-9a-z]*[0-9a-z]*\.)+[a-z0-9][\-a-z0-9]{0,22}[a-z0-9]))$", RegexOptions.IgnoreCase);
            return isEmail;
        }
        #endregion

        #region generateCode
        public static string GenRandomCode()
        {
            string[] pp = ("0,1,2,3,4,5,6,7,8,9").Split(',');
            string tmp = "";
            var rd = new ThreadSafeRandom();
            for (int i = 1; i <= 9; i++)
            {
                tmp += pp[rd.Next(0, pp.Length - 1)];
            }
            return tmp;
        }

        public static string GenOrderCode()
        {
            string[] pp = ("q,w,e,r,t,y,u,i,o,p,a,s,d,f,g,h,j,k,l,z,x,c,v,b,n,m,1,2,3,4,5,6,7,8,9").Split(',');
            string tmp = "";
            var rd = new ThreadSafeRandom();
            for (int i = 1; i <= 7; i++)
            {
                tmp += pp[rd.Next(0, pp.Length - 1)];
            }
            var timeSpan = (long)(DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0)).TotalSeconds;
            return tmp.ToUpper() + timeSpan.ToString();
        }

        public static string Generate6OtpCode()
        {
            var random = new ThreadSafeRandom();
            var result = random.Next(100000, 999999);
            return result.ToString();
        }

        public static string Generate4OtpCode()
        {
            var random = new ThreadSafeRandom();
            var result = random.Next(1000, 9999);
            return result.ToString();
        }
        #endregion

        #region "hashed path file"
        /// <summary>
        /// Bacth: Hash file content into string
        /// for example: 1e5e4212f86d8ecbe5acc956c97fa373
        /// </summary>
        /// <param name="file">file content - array of bytes</param>
        /// <returns>string with 32 characters of length</returns>
        public static string HashFile(byte[] file)
        {
            MD5 md5 = MD5.Create();
            StringBuilder sb = new StringBuilder();

            byte[] hashed = md5.ComputeHash(file);
            foreach (byte b in hashed)
                // convert to hexa
                sb.Append(b.ToString("x2").ToLower());

            // sb = set of hexa characters
            return sb.ToString();
        }

        /// <summary>
        /// Bacth: detemine path to store file
        /// for example: [1e]-[5e]-[42]-[1e5e4212f86d8ecbe5acc956c97fa373]
        /// </summary>
        /// <param name="file">file content - array of bytes</param>
        /// <returns>hashed path</returns>
        public static List<string> GetPath(byte[] file)
        {
            string hashed = HashFile(file);
            List<string> toReturn = new List<string>(3);
            toReturn.Add(hashed.Substring(0, 3));
            toReturn.Add(hashed.Substring(3, 3));
            toReturn.Add(hashed.Substring(6, 3));
            toReturn.Add(hashed);
            return toReturn; // for example: [1e5]-[e42]-[12f]-[1e5e4212f86d8ecbe5acc956c97fa373]
        }
        public static List<String> GetPaths(string md5fileName)
        {
            List<String> toReturn = new List<String>(4);
            toReturn.Add(md5fileName.Substring(0, 3));
            toReturn.Add(md5fileName.Substring(3, 3));
            toReturn.Add(md5fileName.Substring(6, 3));
            toReturn.Add(md5fileName);
            return toReturn; // for example: [1e5]-[e42]-[12f]-[1e5e4212f86d8ecbe5acc956c97fa373]
        }
        #endregion
    }
}
