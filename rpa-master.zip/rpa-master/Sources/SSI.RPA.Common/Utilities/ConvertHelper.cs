﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Threading;

namespace SSI.RPA.Common.Utilities
{
    public class ConvertHelper
    {
        public static bool GetBoolean(object value, bool valueIfNull)
        {
            bool obj = valueIfNull;
            value = GetObject(value, valueIfNull);

            if (value != null)
            {
                if (value is bool) obj = (bool)value;
                else if (value is int)
                {
                    int i = 0;
                    Int32.TryParse(value.ToString(), out i);
                    if (i == 0) obj = false;
                    else obj = true;
                }
                else if (!String.IsNullOrEmpty(value.ToString()))
                {
                    try
                    {
                        obj = Boolean.Parse(value.ToString());
                    }
                    catch { }
                }
            }

            return obj;
        }
        public static string GetString(object value, string valueIfNull)
        {
            string obj = valueIfNull;
            value = GetObject(value, null);
            if (value != null)
            {
                if (!String.IsNullOrEmpty(value.ToString())) obj = value.ToString();
            }
            return obj;
        }
        public static float GetFloat(object value, float valueIfNull)
        {
            float obj = valueIfNull;
            value = GetObject(value, null);
            if (value != null)
            {
                if (value is float) obj = (float)value;
                else if (!String.IsNullOrEmpty(value.ToString()))
                {
                    try { obj = float.Parse(value.ToString()); }
                    catch { }
                }
            }
            return obj;
        }
        public static DateTime ParseDatetimeExact(string value, string format)
        {
            try
            {
                DateTime dt = DateTime.ParseExact(value, format, CultureInfo.InvariantCulture);
                return dt;
            }
            catch (Exception)
            {

                return DateTime.MinValue;
            }
        }
        public static DateTime GetDateTime(object value, DateTime valueIfNull)
        {
            DateTime obj = valueIfNull;
            try
            {
                value = GetObject(value, null);
                if (value != null)
                {
                    if (value is DateTime) obj = (DateTime)value;
                    else if (!String.IsNullOrEmpty(value.ToString()))
                    {
                        try
                        {
                            obj = DateTime.Parse(value.ToString());
                        }
                        catch { }
                    }
                }
                return obj;
            }
            catch
            {
                return obj;
            }
        }
        public static double GetDouble(object value, double valueIfNull)
        {
            double obj = valueIfNull;
            value = GetObject(value, null);
            if (value != null)
            {
                if (value is double) obj = (double)value;
                else if (!String.IsNullOrEmpty(value.ToString()))
                {
                    try { obj = Double.Parse(value.ToString()); }
                    catch { }
                }
            }
            return obj;
        }
        public static decimal GetDecimal(object value, decimal valueIfNull)
        {
            decimal obj = valueIfNull;
            value = GetObject(value, null);
            if (value != null)
            {
                if (value is decimal) obj = (decimal)value;
                else if (!String.IsNullOrEmpty(value.ToString()))
                {
                    try { obj = Decimal.Parse(value.ToString().Replace(",", "")); }
                    catch { }
                }
            }
            return obj;
        }

        public static decimal GetDecimalPercent(object value, decimal valueIfNull)
        {
            decimal obj = valueIfNull;
            value = GetObject(value, null);
            if (value != null)
            {
                if (value is decimal) obj = (decimal)value;
                else if (!String.IsNullOrEmpty(value.ToString()))
                {
                    try { obj = Decimal.Parse(value.ToString().Replace(",", "").Replace("%","")); }
                    catch { }
                }
            }
            return obj * 100;
        }

        public static object GetObject(object value, object valueIfNull)
        {
            object obj = valueIfNull;
            if ((value != null) && (value != DBNull.Value)) obj = value;
            return obj;
        }
        public static long GetInt64(object value, long valueIfNull)
        {
            long obj = valueIfNull;
            value = GetObject(value, null);
            if (value != null)
            {
                if (value is long) obj = (long)value;
                else if (!String.IsNullOrEmpty(value.ToString()))
                {
                    try { obj = Int64.Parse(value.ToString()); }
                    catch { }
                }
            }
            return obj;
        }
        public static int GetInt32(object value, int valueIfNull)
        {
            int obj = valueIfNull;
            value = GetObject(value, null);
            if (value != null)
            {
                if (value is int) obj = (int)value;
                else if (!String.IsNullOrEmpty(value.ToString()))
                {
                    try { obj = Int32.Parse(value.ToString()); }
                    catch { }
                }
            }
            return obj;
        }
        public static string to_dataview(string message)
        {
            if ((message == null) || (message.Equals("")))
            {
                return message;
            }
            else
            {
                string stemp = message;
                stemp = stemp.Replace("<", "&lt;");
                stemp = stemp.Replace(">", "&gt;");
                stemp = stemp.Replace("\r\n", "<br/>");
                stemp = stemp.Replace("\n", "<br/>");
                return stemp;
            }
        }
        public static string to_textcode(string message)
        {
            if ((message == null) || (message.Equals("")))
            {
                return null;
            }
            else
            {
                message = message.Replace("<br/>", "\r");
                message = message.Replace("<br />", "\r");
                message = message.Replace("<br>", "\r");
                return message;
            }
        }
        public static string GetASCIIString(string strUnicode)
        {
            string strRet = "";

            string[] VietnameseSigns = new string[]
            {
            "aAeEoOuUiIdDyY",
            "áàạảãâấầậẩẫăắằặẳẵ",
            "ÁÀẠẢÃÂẤẦẬẨẪĂẮẰẶẲẴ",
            "éèẹẻẽêếềệểễ",
            "ÉÈẸẺẼÊẾỀỆỂỄ",
            "óòọỏõôốồộổỗơớờợởỡ",
            "ÓÒỌỎÕÔỐỒỘỔỖƠỚỜỢỞỠ",
            "úùụủũưứừựửữ",
            "ÚÙỤỦŨƯỨỪỰỬỮ",
            "íìịỉĩ",
            "ÍÌỊỈĨ",
            "đ",
            "Đ",
            "ýỳỵỷỹ",
            "ÝỲỴỶỸ"
            };

            int strLen = strUnicode.Length;
            bool IsFound;
            string strUnicode2 = strUnicode.ToLower();
            for (int i = 0; i < strLen; i++)
            {
                IsFound = false;

                for (int j = 1; j < VietnameseSigns.Length && !IsFound; j++)
                    for (int k = 0; k < VietnameseSigns[j].Length && !IsFound; k++)
                        if (strUnicode2[i] == VietnameseSigns[j][k])
                        {
                            IsFound = true;
                            strRet += VietnameseSigns[0][j - 1];
                        }
                if (!IsFound)
                    if (strUnicode2[i] >= 'A' && strUnicode2[i] <= 'z' || strUnicode2[i] == ' ')
                        strRet += strUnicode2[i];
            }

            if (strRet == "" || strRet == null)
                strRet = "-";

            return strRet.Trim().Replace(" ", "-");
        }

    }
}
