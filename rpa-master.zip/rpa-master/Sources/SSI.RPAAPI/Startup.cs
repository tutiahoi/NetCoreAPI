﻿using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using SSI.RPAService.EF;
using SSI.RPA.Common.Email;
using SSI.RPA.Common.SMS;
using SSI.RPA.Common;
using SSI.RPA.Shared;
using SSI.RPA.Shared.CustomAuthorized;
using SSI.RPAAPI.MapperProfile;
using SSI.RPA.Shared.Security;
using System;
using System.Reflection;
using SSI.RPA.Shared.MapperProfile;
using Microsoft.AspNetCore.Authentication;

namespace SSI.RPAAPI
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCors();
            services.AddControllers();
            services.AddEFConfiguration(Configuration);
            //services.AddConsul(Configuration);
            //services.AddEmailConfiguration(Configuration);
            //services.AddSMSConfiguration(Configuration);
            services.AddAutoMapper(Assembly.GetAssembly(typeof(RPAProfile)));
            services.AddMediatR(Assembly.GetExecutingAssembly());

            //services.AddRedisCache(Configuration);

            //services.AddHttpClient("APIGateway", c =>
            //{
            //    c.BaseAddress = new Uri(Configuration.GetValue<string>("APIGatewayAddress"));
            //});

            //services.AddHttpClient("IGuruAddress", c =>
            //{
            //    c.BaseAddress = new Uri(Configuration.GetValue<string>("IGuruAddress"));
            //});
            
            services.AddHttpContextAccessor();
            services.AddScoped<HttpContextAccessor>();
            services.AddScoped<KeyAuthenFilter>();
            //services.AddSingleton<CryptoProvider>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();

            app.UseRouting();


            //if (Configuration.GetValue<bool>("RegisterInConsul"))
            //{
            //    app.RegToConsul(Configuration);
            //}
            //else
            //{
            //    app.UnregToConsul(Configuration);
            //}

            app.UseCors(x => x
                .AllowAnyOrigin()
                .AllowAnyMethod()
                .AllowAnyHeader());

            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
