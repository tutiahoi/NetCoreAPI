﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SSI.RPA.Shared;
using SSI.RPA.Shared.Dtos;
using SSI.RPA.Shared.CustomAuthorized;
using SSI.RPA.Shared.Domain.Queries;
using SSI.RPA.Common;
using NLog;
using AutoMapper;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace SSI.RPAAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ServiceFilter(typeof(KeyAuthenFilter))]
    public class CashMovementController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly ILogger<CashMovementController> _logger;
        private readonly IMapper _mapper;


        public CashMovementController(IMediator mediator, ILogger<CashMovementController> logger, IMapper mapper)
        {
            _logger = logger;
            _mediator = mediator ?? throw new ArgumentNullException(nameof(mediator));
            _mapper = mapper;
        }

        [Route("list")]
        [HttpPost]
        public async Task<ActionResult> GetCashMovementList([FromBody] GetCashMovementQry request)
        {
            var result = await _mediator.Send(request);            
            var resLog = _mapper.Map<GetCashMovementLogRes>(result);
            var loginfo = new { Request = request.ToJson(), Response = resLog };
            _logger.LogInformation("[GetCashMovementList]: {0}", loginfo.ToJson());
            return new JsonResult(result);
        }        
    }
}
