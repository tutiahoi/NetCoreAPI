﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using SSI.RPA.Common.Utilities;
using SSI.RPA.Shared.Domain.DB;
using SSI.RPA.Shared.Dtos;

namespace SSI.RPAAPI.MapperProfile
{
    public class AOMProfile : Profile
    {
        public AOMProfile()
        {
            
        }
    }
}
