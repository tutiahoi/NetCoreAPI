﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using NLog.Web;
using SSI.RPAAPI;
using SSI.RPA.Shared.CustomConfiguration;

namespace SSI.RPAAPI
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var logConfig = string.IsNullOrEmpty(Environment.GetEnvironmentVariable("env"))
            ? "nlog.config"
            : "nlog.Development.config";
            var logger = NLogBuilder.ConfigureNLog(logConfig).GetCurrentClassLogger();
            logger.Debug("init");

            CreateWebHostBuilder(args).Build().Run();
        }

        public static IWebHostBuilder CreateWebHostBuilder(string[] args)
        {
            var config = new ConfigurationBuilder()
                                .SetBasePath(Directory.GetCurrentDirectory())
                                .AddProtectedJsonFile("appsettings.json", optional: true)
                                .AddProtectedJsonFile("appsettings.Development.json", optional: true)
                                .AddCommandLine(args)
                                .AddEnvironmentVariables()
                                .Build();

            return WebHost.CreateDefaultBuilder(args)
                 .ConfigureAppConfiguration(builder =>
                 {
                     builder.Sources.Clear();
                     builder.AddConfiguration(config);
                 })
                 .UseStartup<Startup>()
                 .ConfigureLogging(logging =>
                 {
                     logging.ClearProviders();
                 })
                 .UseNLog();
        }

    }
}
