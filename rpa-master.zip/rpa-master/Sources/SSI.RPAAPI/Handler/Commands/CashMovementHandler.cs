﻿using AutoMapper;
using MediatR;
using Microsoft.Extensions.Logging;
using SSI.RPA.Shared;
using SSI.RPA.Shared.Domain;
using SSI.RPA.Shared.Enums;
using SSI.RPA.Common;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using SSI.RPAService.EF.Repositories.Interfaces;
using SSI.RPA.Shared.Domain.DB;
using SSI.RPA.Shared.Dtos;
using SSI.RPA.Shared.Domain.Queries;
using System.Collections.Generic;
using System.Globalization;
using SSI.RPA.Shared.MapperProfile;
using AutoMapper.QueryableExtensions;
using SSI.RPA.Common.Utilities;
using Newtonsoft.Json;
using Microsoft.Extensions.Configuration;

namespace SSI.RPAAPI.Handler.Commands
{

    public class CashMovementHandler :
        IRequestHandler<GetCashMovementQry, GetCashMovementRes>
    {
        private readonly ILogger<CashMovementHandler> _logger;
        private readonly ICashMovementRepository _ICashMovementRepository;
        private readonly IMapper _mapper;
        private readonly IConfiguration _configuration;

        public CashMovementHandler(ICashMovementRepository cashMovementRepository,
            ILogger<CashMovementHandler> logger,
            IConfiguration configuration,
            IMapper mapper)
        {
            _logger = logger;
            _mapper = mapper;
            _ICashMovementRepository = cashMovementRepository ?? throw new ArgumentNullException(nameof(cashMovementRepository));
            _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
        }

        public async Task<GetCashMovementRes> Handle(GetCashMovementQry request, CancellationToken cancellationToken)
        {
            var res = new GetCashMovementRes();
            res.ReturnCode = "";
            res.ErrCode = "";
            res.ErrDesc = "";
            res.TransList = new List<PRD_DVCK_CAS_BankCashReconciliationDto>();

            try
            {
                string validateDesc = "";
                if (ValidateGetCashMovementList(request, out validateDesc))
                {
                    var configuration = new MapperConfiguration(cfg => cfg.AddMaps(new[] { typeof(RPAProfile) }));

                    var fromDate = new DateTime();
                    var toDate = new DateTime();
                    DateTime.TryParseExact(request.FromDate, "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, out fromDate);
                    DateTime.TryParseExact(request.ToDate, "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, out toDate);

                    var query = await _ICashMovementRepository.GetCashMovementList(request.ReportType, fromDate, toDate, request.Core, request.BankAccountID);

                    var lstTrans = _mapper.Map<List<PRD_DVCK_CAS_BankCashReconciliationDto>>(query);

                    if (lstTrans != null)
                    {
                        res.TransList = lstTrans;

                        res.ReturnCode = ((int)EReturnCode.SUCCESS).ToString();
                        res.ErrCode = ((int)EStatusAPI.Success).ToString();
                        res.ErrDesc = "Thành công";
                    }
                    else
                    {
                        res.ReturnCode = ((int)EReturnCode.FAIL).ToString();
                        res.ErrCode = ((int)EStatusAPI.Exception).ToString();
                        res.ErrDesc = EStatusAPI.Exception.GetDescription();
                    }
                }
                else
                {
                    res.ReturnCode = ((int)EReturnCode.FAIL).ToString();
                    res.ErrCode = ((int)EStatusAPI.InvalidInput).ToString();
                    res.ErrDesc = validateDesc;
                }

                return res;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);

                res.ReturnCode = ((int)EReturnCode.FAIL).ToString();
                res.ErrCode = ((int)EStatusAPI.Exception).ToString();
                res.ErrDesc = ex.Message;

                return res;
            }
        }

        private bool ValidateGetCashMovementList(GetCashMovementQry qry, out string desc)
        {
            if (!qry.FromDate.IsStringNullOrEmpty())
            {
                var d = new DateTime();
                if (!DateTime.TryParseExact(qry.FromDate, "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, out d))
                {
                    desc = "FromDate sai format yyyyMMdd";
                    return false;
                }
            }
            else
            {
                desc = "FromDate khong duoc de trong";
                return false;
            }

            if (!qry.ToDate.IsStringNullOrEmpty())
            {
                var todate = new DateTime();
                if (!DateTime.TryParseExact(qry.ToDate, "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, out todate))
                {
                    desc = "ToDate sai format yyyyMMdd";
                    return false;
                }
                else
                {
                    if (todate.Date > DateTime.Now.Date)
                    {
                        desc = "ToDate phai nho hon hoac bang ngay hien tai";
                        return false;
                    }
                    else
                    {
                        var fromdate = new DateTime();
                        DateTime.TryParseExact(qry.FromDate, "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, out fromdate);

                        if (fromdate.AddDays(365).Date < todate.Date)
                        {
                            desc = "Khoang FromDate - ToDate khong duoc qua 365 ngay";
                            return false;
                        }
                    }
                }
            }
            else
            {
                desc = "ToDate khong duoc de trong";
                return false;
            }

            desc = "";
            return true;
        }
    }
}
