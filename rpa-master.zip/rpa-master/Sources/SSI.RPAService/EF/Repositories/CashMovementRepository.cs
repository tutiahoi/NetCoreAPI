﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using SSI.RPA.Shared.Domain.DB;
using SSI.RPA.Shared.MapperProfile;
using SSI.RPAService.EF.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SSI.RPAService.EF.Repositories
{
    public class CashMovementRepository : ICashMovementRepository
    {
        private readonly ILogger<CashMovementRepository> _logger;
        private readonly RPAContext _dbContext;
        private readonly IMapper _mapper;

        public CashMovementRepository(RPAContext dbContext, ILogger<CashMovementRepository> logger, IMapper mapper)
        {
            _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
            _mapper = mapper;
            _logger = logger;
        }

        public async Task<List<PRD_DVCK_CAS_BankCashReconciliation>> GetCashMovementList(string reportType, DateTime fromDate, DateTime toDate, string core, string bankAccountID)
        {
            var pReportType = new SqlParameter("@ReportType", reportType);
            var pFromDate = new SqlParameter("@FromDate", fromDate);
            var pToDate = new SqlParameter("@ToDate", toDate);
            var pBankAccountID = new SqlParameter("@BankAccountID", bankAccountID);
            var pSourceSystem = new SqlParameter("@SourceSystem", core);

            var res = _dbContext
                .PRD_DVCK_CAS_BankCashReconciliation
                .FromSqlRaw($"EXECUTE PRD_DVCK_CAS_BankCashReconciliation @ReportType, @FromDate, @ToDate, @BankAccountID, @SourceSystem", pReportType, pFromDate, pToDate, pBankAccountID, pSourceSystem)
                .AsNoTracking()
                .ToList();            

            return res;
        }
    }
}
