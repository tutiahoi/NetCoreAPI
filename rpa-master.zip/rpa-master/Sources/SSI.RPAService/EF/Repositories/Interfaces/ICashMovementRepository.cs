﻿using SSI.RPA.Shared.Domain.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SSI.RPAService.EF.Repositories.Interfaces
{
    public interface ICashMovementRepository
    {
        Task<List<PRD_DVCK_CAS_BankCashReconciliation>> GetCashMovementList(string reportType, DateTime fromDate, DateTime toDate, string core, string bankAccountID);
    }
}
