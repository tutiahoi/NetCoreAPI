﻿using Microsoft.EntityFrameworkCore;
using SSI.RPA.Shared.Domain.DB;

namespace SSI.RPAService.EF
{
    public class RPAContext : DbContext
    {
        public RPAContext() : base() { }
        public RPAContext(DbContextOptions<RPAContext> options) : base(options)
        {
            ChangeTracker.AutoDetectChangesEnabled = false;
        }

        public DbSet<PRD_DVCK_CAS_BankCashReconciliation> PRD_DVCK_CAS_BankCashReconciliation { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.EnableSensitiveDataLogging();
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {            
            modelBuilder.Entity<PRD_DVCK_CAS_BankCashReconciliation>().HasKey(e => e.OrigTranID);            
        }
    }
}

