﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using SSI.RPAService.EF.Repositories;
using SSI.RPAService.EF.Repositories.Interfaces;
using System;

namespace SSI.RPAService.EF
{
    public static class EFInstaller
    {
        public static IServiceCollection AddEFConfiguration(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddDbContext<RPAContext>(options =>
            {
                options.UseSqlServer(configuration.GetConnectionString("RPAConnection"),
                    sqlServerOptionsAction: sqlOptions =>
                    {
                        sqlOptions.CommandTimeout(90);
                        sqlOptions.EnableRetryOnFailure(
                            maxRetryCount: 3,
                            maxRetryDelay: TimeSpan.FromSeconds(30),
                            errorNumbersToAdd: null);
                    });
                options.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking);

            });
            
            services.AddScoped<ICashMovementRepository, CashMovementRepository>();            
            return services;
        }
    }
}
